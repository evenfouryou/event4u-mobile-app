/*****************************************************************************
               Funzioni esportate dalla libreria "libSIAEcard"
*****************************************************************************/

#include <memory.h>
#include <string.h>
#include "scardHAL.h"
#include "libSIAECard.h"
#include "internals.h"

int Select(WORD fid)
{
  WORD SW;
  int x;
  BYTE pSend[2];
  pSend[0]=(BYTE)((fid&0xff00)>>8);
  pSend[1]=(BYTE)(fid&0x00ff);
  x=SendAPDU(APDU_SELECT,2,0,pSend,0,&SW);
  if (x!=C_OK) return x;
  if (SW!=0x9000) return SW;
  return C_OK;
}

int ReadBinary(WORD Offset, BYTE *Buffer, int *Len)
{
  int rv=C_GENERIC_ERROR;
  WORD SW=0;
  WORD Offset1;
  DWORD dimDati;
  DWORD index;
  BYTE blockLen;
  int letti=0;
  BYTE tmpBuffer[256];
  /* Verifica dei parametri */
  if (!IsInitialized())
    return C_NOT_INITIALIZED;
  if (Buffer==NULL)
    return C_GENERIC_ERROR;
  if ((Len==NULL)||(*Len==0))
    return C_GENERIC_ERROR;
  Offset1 = Offset;
  dimDati = *Len;
  index=0;
  blockLen=EXCHANGE_BUFFER;
  /* Il buffer viene letto a blocchi di dimensioni pari a EXCHANGE_BUFFER.  */
  /* Il valore massimo di EXCHANGE_BUFFER secondo le specifiche PC/SC � 249 */
  /* tuttavia non tutti i lettori riescono a lavorare correttamente con     */
  /* buffer di tali dimensioni.                                             */
  while (dimDati>=EXCHANGE_BUFFER) {
    rv=SendAPDU(APDU_READBINARY|Offset1,0,&blockLen,0,tmpBuffer,&SW);
    if (rv!=C_OK) return rv;
    if ((SW!=SW_OK)&&(SW!=SW_WRONG_LENGTH)) return SW;
    memcpy(Buffer+letti,tmpBuffer,blockLen);
    if (blockLen!=EXCHANGE_BUFFER) {
      *Len=letti;
      return C_WRONG_LENGTH;
    }
    dimDati-=EXCHANGE_BUFFER;
    letti+=blockLen;
    Offset1 = (WORD)(Offset1 + blockLen);
  }
  if (dimDati>0) {
    rv=SendAPDU(APDU_READBINARY|Offset1,0,(BYTE*)&dimDati,0,tmpBuffer,&SW);
    if (rv!=C_OK) return rv;
    if ((SW!=SW_OK)&&(SW!=SW_WRONG_LENGTH)) return SW;
    memcpy(Buffer+letti,tmpBuffer,dimDati);
    letti+=dimDati;
  }
  if ((rv!=C_OK)&&(rv!=SW_WRONG_LENGTH)) return SW;
  *Len=letti;
  return C_OK;
}

int ReadRecord( int nRec, BYTE* Buffer, int *Len)
{
  WORD SW=0;
  int rv=C_OK;
  if (!IsInitialized()) return C_NOT_INITIALIZED;
  if ((Buffer==NULL)&&(Len==NULL)) return C_GENERIC_ERROR;
  if ((Len==NULL)||(*Len>255)) return C_WRONG_LENGTH;
  if (nRec>255) return C_RECORD_NOT_FOUND;
  rv=SendAPDU(APDU_READRECORD|0x00000004|(WORD)(nRec<<8),0,(BYTE*)Len,NULL,Buffer,&SW);
  return C_OK;
}

int VerifyPIN(int nPIN, char *pin)
{
  int rv=C_OK;
  WORD SW=0;
  if (!IsInitialized()) return C_NOT_INITIALIZED;
  if (nPIN!=1) return C_GENERIC_ERROR;
  rv=SendAPDU(APDU_VERIFYPIN|0x00000081,(BYTE)strlen(pin),NULL,(BYTE*)pin,NULL,&SW);
  if (rv!=C_OK) return rv;
  if (SW==SW_AUTH_FAILED)
  {
    rv=SendAPDU(APDU_VERIFYPIN|0x00000081,0,NULL,NULL,NULL,&SW);
    return SW;
  }
  if (SW!=SW_OK) return SW;
  return C_OK;
}

int ChangePIN(int nPIN, char *Oldpin, char *Newpin)
{
  int rv=C_OK;
  WORD SW=0;
  BYTE sBuff[256];
  if (!IsInitialized()) return C_NOT_INITIALIZED;
  if (nPIN!=1) return C_GENERIC_ERROR;
  memcpy(sBuff,Oldpin,strlen(Oldpin));
  memcpy(sBuff+strlen(Oldpin),Newpin,strlen(Newpin));
  rv=SendAPDU(APDU_CRD|0x00000081,(BYTE)(strlen(Oldpin)+strlen(Newpin)),0,sBuff,NULL,&SW);
  if (rv!=C_OK) return rv;
  if (SW==SW_AUTH_FAILED)
  {
    /* La seguente APDU viene inviata alla carta per ottenere il numero */
    /* di tentativi di verifica PIN rimanenti                           */
    rv=SendAPDU(APDU_VERIFYPIN|0x00000081,0,NULL,NULL,NULL,&SW);
    return SW;
  }
  if (SW!=SW_OK) return SW;
  return C_OK;
}

int UnblockPIN(int nPIN, char *Puk, char *Newpin)
{
  int rv=C_OK;
  WORD SW=0;
  BYTE sBuff[256], oBuff[128]; BYTE bLen;
  if (!IsInitialized()) return C_NOT_INITIALIZED;
  if (nPIN!=1) return C_GENERIC_ERROR;
  memcpy(sBuff,Puk,strlen(Puk));
  memcpy(sBuff+strlen(Puk),Newpin,strlen(Newpin));
  bLen = 0;
  rv=SendAPDU(APDU_RRC|0x00000081,(BYTE)(strlen(Newpin)+strlen(Puk)),&bLen,sBuff,
              oBuff,&SW);
  if (rv!=C_OK) return rv;
  if (SW==SW_AUTH_FAILED)
  {
    /* La seguente APDU viene inviata alla carta per ottenere il numero */
    /* di tentativi di verifica PUK rimanenti                           */
    rv=SendAPDU(APDU_VERIFYPIN|0x00000082,0,NULL,NULL,NULL,&SW);
    return SW;
  }
  if (SW!=SW_OK) return SW;
  return C_OK;
}

int ReadCounter(DWORD *value)
{
  int rv=C_OK;
  WORD SW=0;
  BYTE tmp[4];
  BYTE len=4;
  if (!IsInitialized()) return C_NOT_INITIALIZED;
  rv=Select(FID_MF);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_SIAE_APP_DOMAIN);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_SIAE_CNT_DOMAIN);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_EF_CNT);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=SendAPDU(APDU_READ_COUNTER,0,&len,NULL,tmp,&SW);
  if (rv!=C_OK) return rv;
  if (SW!=SW_OK) return SW;
  if (len!=4) return C_WRONG_LENGTH;
  *value=(DWORD)(tmp[0]<<24|tmp[1]<<16|tmp[2]<<8|tmp[3]);
  return C_OK;
}

int ReadBalance(DWORD *value)
{
  int rv=C_OK;
  WORD SW=0;
  BYTE tmp[4];
  BYTE len=4;
	if (!IsInitialized()) return C_NOT_INITIALIZED;
  rv=Select(FID_MF);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_SIAE_APP_DOMAIN);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_SIAE_CNT_DOMAIN);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_EF_BALANCE_CNT);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=SendAPDU(APDU_READ_COUNTER,0,&len,NULL,tmp,&SW);
  if (rv!=C_OK) return rv;
  if (SW!=SW_OK) return SW;
  if (len!=4) return C_WRONG_LENGTH;
  *value=(DWORD)(tmp[0]<<24|tmp[1]<<16|tmp[2]<<8|tmp[3]);
  return C_OK;
}

int ComputeSigillo(BYTE *Data_Ora,DWORD Prezzo,BYTE *SN,
           BYTE *mac,DWORD *cnt)
{
  int rv=C_OK;
  WORD SW=0;
  BYTE tmp[12];
  BYTE len=12;
  BYTE pSend[22];
  if (!IsInitialized()) return C_NOT_INITIALIZED;
  rv=Select(FID_MF);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_SIAE_APP_DOMAIN);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_SIAE_CNT_DOMAIN);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_EF_CNT);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  /* Preparazione Challenge */
  memcpy(pSend,(BYTE*)"\x00\x01",2);
  memcpy(pSend+2,SN,8);
  memcpy(pSend+10,Data_Ora,8);
  pSend[18]=(BYTE)((Prezzo&0xff00000000)>>24);
  pSend[19]=(BYTE)((Prezzo&0x0000ff0000)>>16);
  pSend[20]=(BYTE)((Prezzo&0x000000ff0)>>8);
  pSend[21]=(BYTE)(Prezzo&0x00000000ff);
  rv=SendAPDU(APDU_CMP_SIGILLO,22,&len,pSend,tmp,&SW);
  if (rv!=C_OK) return rv;
  if (SW!=SW_OK) return SW;
  *cnt=(tmp[0]<<24)|(tmp[1]<<16)|(tmp[2]<<8)|tmp[3];
  memcpy(mac,&tmp[4],8);
  return C_OK;
}

int Padding(BYTE *toPad, int Len, BYTE *Padded)
{
  BYTE *p;
  int i=0;
  p=Padded;
  *(p++)=0; *(p++)=1;
  for (i=0; i<128-Len-3; i++)
    *(p++)=255;
  *(p++)=0;
  memcpy(p,toPad,Len);
  return C_OK;
}

int Sign(int kx,BYTE *toSign,BYTE *Signed)
{
  int rv=C_OK;
  BYTE pSendMSE[3];
  BYTE pSendSGN[255];
  WORD SW=0;
  BYTE len=128;
  if (!IsInitialized()) return C_NOT_INITIALIZED;
  if (kx>255) return C_UNKNOWN_OBJECT;
  rv=Select(FID_MF);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_SIAE_APP_DOMAIN);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  rv=Select(FID_P11_APP_DOMAIN);
  if (rv!=C_OK) return C_FILE_NOT_FOUND;
  pSendMSE[0]=0x83; pSendMSE[1]=0x01; pSendMSE[2]=(BYTE)kx;
  rv=SendAPDU(APDU_MSE,3,NULL,pSendMSE,NULL,&SW);
  if (rv!=C_OK) return rv;
  if (SW!=SW_OK) return SW;
  pSendSGN[0]=0;
  memcpy(pSendSGN+1,toSign,128);
  rv=SendAPDU(APDU_SIGN,129,&len,pSendSGN,Signed,&SW);
  if (rv!=C_OK) return rv;
  if (SW!=SW_OK) return SW;
  return C_OK;
}

