/*****************************************************************************
                          Hardware Abstraction Layer
Le funzioni contenute nel presente file sono system dependent. E' necessario
provvedere a scrivere funzioni equivalenti cambiando ambiente di sviluppo.
*****************************************************************************/

/*\
 *  WINSCARD PER PCSC SU PIATTAFORMA MICROSOFT
\*/
#include <winscard.h>
#ifdef WIN32
#pragma comment(lib,"winscard.lib")
#endif

/*\
 *  OPENSSL PER FUNZIONI DI HASHING
\*/
#include <openssl/x509.h>
#include <openssl/x509v3.h>
#ifdef WIN32
#if _DEBUG
#pragma comment(lib, "libeay32d.lib")
#else
#pragma comment(lib, "libeay32.lib")
#endif
#endif

#include "libSIAECard.h"

#define ATR_SIAE_CARD \
	"\x3b\xfb\x11\x00\xff\x81\x31\x80\x55\x00" \
	"\x68\x02\x00\x10\x10\x53\x49\x41\x45\x00\x04"
#define ATR_LEN 0x15

/* hContext � una variabile globale e rappresenta il contesto PC/SC */
/* della applicazione */
static SCARDCONTEXT hContext=0;

/* hCard � l'handle che individua univocamente il canale PC/SC */
/* aperto con una smart card */
static SCARDHANDLE  hCard=0;

/* initialized � una variabile booleana globale che viene utilizzata */
/* per tenere traccia dell'inizializzazione della libreria */
static BOOL initialized=FALSE;

/* Variabili e funzioni ad uso interno */
static LPTSTR pszReaderNames=NULL;
static DWORD cch=0;
static char *GetReaderName(int Slot);

BOOL IsInitialized()
{
	return initialized;
}

/* La funzione Initialize effettua le seguenti operazioni:   */
/* - Stabilisce il contesto PC/SC con il resource manager    */
/* - Effettua la connessione con il lettore (slot) richiesto */
/* - Inizializza le variabili di ambiente                    */
/* - Sancisce l'inizio di una transazione PC/SC              */
int Initialize(int Slot)
{
  long rv=SCARD_S_SUCCESS;
  DWORD rL=0;
  DWORD dwState=0;
  DWORD dwProtocol=0;
  BYTE *pbAtr=NULL;
  DWORD cByte=0;
  /* Controllo che la libreria non sia gi� inizializzata */
  if (initialized==TRUE)
    return C_ALREADY_INITIALIZED;
  /* Rilascio un contesto eventualmente rimasto aperto */
  if (hContext!=0) {
    SCardReleaseContext(hContext);
    hContext=0;
  }
  rv=SCardEstablishContext(SCARD_SCOPE_USER,NULL,NULL,&hContext);
  if (rv!=SCARD_S_SUCCESS) {
    initialized=FALSE;
    hContext=0;
    return C_CONTEXT_ERROR;
  } else {
    DWORD dwActiveProtocol=0;
	char *myReaderName = (char *)malloc(100);
    rv=SCardConnect(hContext,GetReaderName(Slot),SCARD_SHARE_SHARED,
    	SCARD_PROTOCOL_T1,&hCard,&dwActiveProtocol);
    switch (rv)
    {
      case SCARD_E_NO_SMARTCARD: 
        if (pszReaderNames!=NULL) free(pszReaderNames);
        pszReaderNames=NULL;
        free(myReaderName);
        return C_NO_CARD;
      case SCARD_W_REMOVED_CARD: 
        if (pszReaderNames!=NULL) free(pszReaderNames);
        pszReaderNames=NULL;
        free(myReaderName);
        return C_NO_CARD;
      case SCARD_E_PROTO_MISMATCH: 
        if (pszReaderNames!=NULL) free(pszReaderNames);
        pszReaderNames=NULL;
        free(myReaderName);
        return C_UNKNOWN_CARD;
      case SCARD_S_SUCCESS:
		cByte = 100;
		rL = 100;
        pbAtr=(BYTE*)malloc(cByte);
        rv = SCardStatus(hCard,myReaderName,&rL,&dwState,&dwProtocol,pbAtr,&cByte);
        free(myReaderName);
        if (rv!=SCARD_S_SUCCESS) {
          SCardDisconnect(hCard,SCARD_LEAVE_CARD);
          hCard=0;
          return C_GENERIC_ERROR;
        }
        if (cByte!=ATR_LEN) {
          SCardDisconnect(hCard,SCARD_LEAVE_CARD);
          hCard=0;
          return C_UNKNOWN_CARD;
        }
        if ((memcmp(pbAtr,ATR_SIAE_CARD,ATR_LEN)!=0)&&
        	(rv==SCARD_S_SUCCESS)) {
          SCardDisconnect(hCard,SCARD_LEAVE_CARD);
          free(pbAtr);
          return C_UNKNOWN_CARD;
        }
        free(pbAtr);
        initialized=TRUE;
        SCardBeginTransaction(hCard);
        return C_OK;
      break;
      default: return C_GENERIC_ERROR;
    }
  }
  initialized=TRUE;
  return C_OK;
}

/* La funzione Finalize effettua le seguenti operazioni: */
/* - Termina la transazione PC/SC                        */
/* - Chiude il canale PC/SC con la carta                 */
/* - Rilascia il contesto PC/SC hContext                 */
int Finalize()
{
  if (!initialized) return C_NOT_INITIALIZED;
  if (pszReaderNames!=NULL) free(pszReaderNames);
  pszReaderNames=NULL;
  SCardEndTransaction(hCard,SCARD_LEAVE_CARD);
  SCardDisconnect(hCard,SCARD_LEAVE_CARD);
  SCardReleaseContext(hContext);
  hCard=0; hContext=0;
  initialized=FALSE;
  return C_OK;
}

/* La funzione Hash � stata implementata nel presente file    */
/* in quanto, in essa, vengono chiamate funzioni di OpenSSL   */
/* qualora l'ambiente di interesse non supporti tale libreria */
/* � necessario provvedere ad una implementazione equivalente */
/* della funzione.                                            */
int Hash(int mec,BYTE *toHash, int Len, BYTE *Hashed)
{
  switch (mec)
  {
    case HASH_SHA1:
      SHA1(toHash,Len,Hashed);
    case HASH_MD5:
      MD5(toHash,Len,Hashed);
    default:
    return C_GENERIC_ERROR;
  }
  return C_OK;
}

/* La funzione SendAPDU invia una APDU alla smart card */
int SendAPDU(DWORD cmd, BYTE Lc, BYTE *pLe,
										BYTE *inBuffer, BYTE *outBuffer, WORD *pSW)
{
  long rv=SCARD_S_SUCCESS;
  DWORD tLen=256;
  BYTE tmpBuf[256];
  BYTE pSendBuffer[256];
  DWORD lSB; /*lunghezza del buffer da inviare alla carta*/
  pSendBuffer[0]=(BYTE)((cmd&0xff000000)>>24);
  pSendBuffer[1]=(BYTE)((cmd&0x00ff0000)>>16);
  pSendBuffer[2]=(BYTE)((cmd&0x0000ff00)>>8);
  pSendBuffer[3]=(BYTE) (cmd&0x000000ff);
  lSB=4;
  if (Lc!=0) {
    pSendBuffer[4]=Lc;
    memcpy(pSendBuffer+5,inBuffer,Lc);
    lSB+=Lc+1;
  }
  if(pSendBuffer[1]==0xa4) {
		pSendBuffer[lSB]=(pLe!=NULL)?*pLe:0;
	  lSB++;
	}
  tLen=256;
  rv=SCardTransmit(hCard,SCARD_PCI_T1,pSendBuffer,lSB,NULL,tmpBuf,&tLen);
	if (rv!=SCARD_S_SUCCESS) {
    if (pLe!=NULL) *pLe=0;
    return rv;
  } else *pSW=(tmpBuf[tLen-2]<<8)|tmpBuf[tLen-1];
  if (tLen>2) {
    if (outBuffer!=NULL)
      memcpy(outBuffer,tmpBuf,(*pLe>tLen-2)?(tLen-2):*pLe);
    if (pLe!=NULL)
      if ((*pLe>tLen-2)||(outBuffer==NULL)) *pLe=(BYTE)(tLen-2);
  }
  return C_OK;
}

static char *GetReaderName(int Slot)
{
  long rv=SCardListReaders(hContext,NULL,NULL,&cch);
  pszReaderNames = (LPTSTR) malloc(cch);
  if (pszReaderNames == 0) return NULL;
  rv=SCardListReaders(hContext,NULL,pszReaderNames,&cch);
  if (rv==SCARD_S_SUCCESS)
  {
    int q=0;
    LPTSTR pReader=pszReaderNames;
    do {
      if (q==Slot) return pReader;
      else
        pReader+=strlen(pReader)+1;
      q++;
    } while ((*pReader!='\0')&&(q<=Slot));
  }
  return NULL;
}
