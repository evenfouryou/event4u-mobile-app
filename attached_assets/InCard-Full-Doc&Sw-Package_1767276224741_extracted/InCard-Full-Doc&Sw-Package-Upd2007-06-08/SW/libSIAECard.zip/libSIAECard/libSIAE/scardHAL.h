#include <winscard.h>

BOOL IsInitialized();

int Initialize(int Slot);

int Finalize();

int Hash(int mec,BYTE *toHash, int Len, BYTE *Hashed);

int SendAPDU(DWORD cmd, BYTE Lc, BYTE *pLe, BYTE *inBuffer, BYTE *outBuffer, WORD *pSW);






