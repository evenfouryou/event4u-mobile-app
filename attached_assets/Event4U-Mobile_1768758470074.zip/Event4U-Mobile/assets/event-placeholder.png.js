// Placeholder - replace with actual image
// This file exists to prevent import errors during development
export default {};
