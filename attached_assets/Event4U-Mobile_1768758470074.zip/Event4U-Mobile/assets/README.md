Assets folder ready - add icon.png, splash.png, adaptive-icon.png, favicon.png, event-placeholder.png
