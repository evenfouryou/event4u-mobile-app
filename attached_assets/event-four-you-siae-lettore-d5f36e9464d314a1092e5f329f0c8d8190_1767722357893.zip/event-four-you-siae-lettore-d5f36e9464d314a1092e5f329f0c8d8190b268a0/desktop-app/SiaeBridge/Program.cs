using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Security.Cryptography;
using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using Newtonsoft.Json;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.Cms;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Asn1.Pkcs;
using Org.BouncyCastle.Cms;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Digests;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using BCX509 = Org.BouncyCastle.X509;

namespace SiaeBridge
{
    class Program
    {
        // ============================================================
        // IMPORT libSIAE.dll - StdCall calling convention (confirmed)
        // ============================================================
        private const string DLL = "libSIAE.dll";

        [DllImport(DLL, CallingConvention = CallingConvention.StdCall)]
        static extern int isCardIn(int slot);

        [DllImport(DLL, CallingConvention = CallingConvention.StdCall)]
        static extern int Initialize(int slot);

        [DllImport(DLL, CallingConvention = CallingConvention.StdCall)]
        static extern int FinalizeML(int slot);

        [DllImport(DLL, CallingConvention = CallingConvention.StdCall)]
        static extern int BeginTransactionML(int slot);

        [DllImport(DLL, CallingConvention = CallingConvention.StdCall)]
        static extern int EndTransactionML(int slot);

        [DllImport(DLL, CallingConvention = CallingConvention.StdCall)]
        static extern int GetSNML(byte[] sn, int slot);

        [DllImport(DLL, CallingConvention = CallingConvention.StdCall)]
        static extern int ReadCounterML(ref uint val, int slot);

        [DllImport(DLL, CallingConvention = CallingConvention.StdCall)]
        static extern int ReadBalanceML(ref uint val, int slot);

        [DllImport(DLL, CallingConvention = CallingConvention.StdCall)]
        static extern byte GetKeyIDML(int slot);

        [DllImport(DLL, CallingConvention = CallingConvention.StdCall)]
        static extern int ComputeSigilloML(byte[] dt, uint price, byte[] sn, byte[] mac, ref uint cnt, int slot);

        // PIN deve essere passato come puntatore a stringa ANSI null-terminated
        [DllImport(DLL, CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
        static extern int VerifyPINML(int nPIN, [MarshalAs(UnmanagedType.LPStr)] string pin, int nSlot);

        // ============================================================
        // IMPORT libSIAEp7.dll - per firme PKCS#7/P7M (CAdES-BES)
        // ============================================================
        private const string DLL_P7 = "libSIAEp7.dll";

        [DllImport(DLL_P7, CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
        static extern int PKCS7SignML(
            [MarshalAs(UnmanagedType.LPStr)] string pin,
            uint slot,
            [MarshalAs(UnmanagedType.LPStr)] string szInputFileName,
            [MarshalAs(UnmanagedType.LPStr)] string szOutputFileName,
            int bInitialize);

        // Windows API
        [DllImport("winscard.dll", CharSet = CharSet.Unicode)]
        static extern int SCardListReadersW(IntPtr hContext, string mszGroups, byte[] mszReaders, ref int pcchReaders);

        [DllImport("winscard.dll")]
        static extern int SCardEstablishContext(int dwScope, IntPtr pvReserved1, IntPtr pvReserved2, ref IntPtr phContext);

        [DllImport("winscard.dll")]
        static extern int SCardReleaseContext(IntPtr hContext);

        // ============================================================
        // STATE
        // ============================================================
        static int _slot = -1;
        static StreamWriter _log;

        // ============================================================
        // MAIN
        // ============================================================
        static void Main()
        {
            string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bridge.log");
            try { _log = new StreamWriter(logPath, true) { AutoFlush = true }; } catch { }

            Log("═══════════════════════════════════════════════════════");
            Log("SiaeBridge v3.18 - FIX: Added DLL copy to output in .csproj (libSIAE.dll was missing)");
            Log($"Time: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            Log($"Dir: {AppDomain.CurrentDomain.BaseDirectory}");
            Log($"32-bit Process: {!Environment.Is64BitProcess}");

            string dllPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "libSIAE.dll");
            if (File.Exists(dllPath))
            {
                Log($"✓ libSIAE.dll: {new FileInfo(dllPath).Length} bytes");
            }
            else
            {
                Log("✗ libSIAE.dll NOT FOUND!");
            }

            string dllP7Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "libSIAEp7.dll");
            if (File.Exists(dllP7Path))
            {
                Log($"✓ libSIAEp7.dll: {new FileInfo(dllP7Path).Length} bytes (PKCS7/P7M signing)");
            }
            else
            {
                Log("✗ libSIAEp7.dll NOT FOUND - P7M signing will fail!");
            }

            Console.WriteLine("READY");
            Log("Bridge READY");

            string line;
            while ((line = Console.ReadLine()) != null)
            {
                line = line.Trim();
                if (string.IsNullOrEmpty(line)) continue;

                Log($">> {line}");
                string response = Handle(line);
                Console.WriteLine(response);
                Log($"<< {(response.Length > 300 ? response.Substring(0, 300) + "..." : response)}");
            }
        }

        static void Log(string msg)
        {
            try { _log?.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] {msg}"); } catch { }
        }

        // ============================================================
        // Check if card is present
        // ============================================================
        static bool IsCardPresent(int state)
        {
            // libSIAE.dll isCardIn() returns:
            // - 0 = no card or no reader
            // - 1 = card present (simple boolean, NOT a bitmask!)
            // - Other non-zero values also indicate card present
            return state > 0;
        }

        static string DecodeCardState(int state)
        {
            // libSIAE.dll returns simple values: 0=no card, 1=card present
            if (state == 0) return "NO_CARD";
            if (state == 1) return "CARD_PRESENT";
            return $"PRESENT({state})";
        }

        // ============================================================
        // COMMAND HANDLER
        // ============================================================
        static string Handle(string cmd)
        {
            try
            {
                if (cmd == "PING") return OK("PONG");
                if (cmd == "EXIT") { Environment.Exit(0); return OK("BYE"); }
                if (cmd == "CHECK_READER") return CheckReader();
                if (cmd == "READ_CARD") return ReadCard();
                if (cmd == "READ_EFFF") return ReadEfff();
                if (cmd == "GET_CERTIFICATE") return GetCertificate();
                if (cmd == "GET_RETRIES") return GetRetries();
                if (cmd.StartsWith("VERIFY_PIN:")) return VerifyPin(cmd.Substring(11));
                if (cmd.StartsWith("CHANGE_PIN:")) return ChangePin(cmd.Substring(11));
                if (cmd.StartsWith("UNLOCK_PUK:")) return UnlockPuk(cmd.Substring(11));
                if (cmd.StartsWith("COMPUTE_SIGILLO:")) return ComputeSigillo(cmd.Substring(16));
                if (cmd.StartsWith("SIGN_XML:")) return SignXml(cmd.Substring(9));
                if (cmd.StartsWith("SIGN_SMIME:")) return SignSmime(cmd.Substring(11));
                return ERR($"Comando sconosciuto: {cmd}");
            }
            catch (DllNotFoundException ex)
            {
                Log($"DllNotFoundException: {ex.Message}");
                return ERR("libSIAE.dll non trovata");
            }
            catch (Exception ex)
            {
                Log($"Exception: {ex.GetType().Name}: {ex.Message}");
                return ERR(ex.Message);
            }
        }

        static string OK(object data) => JsonConvert.SerializeObject(new { success = true, data });
        static string ERR(string msg) => JsonConvert.SerializeObject(new { success = false, error = msg });

        // ============================================================
        // CHECK READER
        // ============================================================
        static string CheckReader()
        {
            bool hasReaders = CheckWindowsSmartCardReaders();
            Log($"Windows readers: {hasReaders}");

            if (!hasReaders)
            {
                return JsonConvert.SerializeObject(new
                {
                    success = true,
                    readerConnected = false,
                    cardPresent = false,
                    message = "Nessun lettore rilevato"
                });
            }

            try
            {
                for (int s = 0; s < 16; s++)
                {
                    try
                    {
                        int state = isCardIn(s);
                        string decoded = DecodeCardState(state);
                        Log($"  isCardIn({s}) = {state} = {decoded}");

                        // state <= 0 means no reader at this slot, stop scanning
                        if (state <= 0)
                        {
                            Log($"  No reader at slot {s}, stopping scan");
                            break;
                        }

                        // state > 0 means card is present (libSIAE returns 1 for card present)
                        Log($"  ✓ CARTA PRESENTE in slot {s}!");

                        // Reset card state before initialize
                        int finRes = FinalizeML(s);
                        Log($"  FinalizeML({s}) = {finRes}");
                        
                        // Try to initialize
                        Log($"  Trying Initialize({s})...");
                        int init = Initialize(s);
                        Log($"  Initialize({s}) = {init} (0x{init:X4})");

                        _slot = s;

                        if (init == 0 || init == 3) // 0=OK, 3=already initialized
                        {
                            return JsonConvert.SerializeObject(new
                            {
                                success = true,
                                readerConnected = true,
                                cardPresent = true,
                                slot = s,
                                cardState = decoded,
                                initResult = init,
                                message = "Carta SIAE rilevata e pronta!"
                            });
                        }
                        else
                        {
                            return JsonConvert.SerializeObject(new
                            {
                                success = true,
                                readerConnected = true,
                                cardPresent = true,
                                slot = s,
                                cardState = decoded,
                                initResult = init,
                                warning = $"Initialize returned 0x{init:X4}",
                                message = "Carta rilevata (init warning)"
                            });
                        }
                    }
                    catch (Exception ex)
                    {
                        Log($"  Slot {s} error: {ex.Message}");
                        break;
                    }
                }

                return JsonConvert.SerializeObject(new
                {
                    success = true,
                    readerConnected = true,
                    cardPresent = false,
                    message = "Inserire carta SIAE"
                });
            }
            catch (Exception ex)
            {
                Log($"CheckReader error: {ex.Message}");
                return JsonConvert.SerializeObject(new
                {
                    success = false,
                    readerConnected = hasReaders,
                    cardPresent = false,
                    error = ex.Message
                });
            }
        }

        static bool CheckWindowsSmartCardReaders()
        {
            try
            {
                IntPtr context = IntPtr.Zero;
                int result = SCardEstablishContext(2, IntPtr.Zero, IntPtr.Zero, ref context);
                if (result != 0) return false;

                int size = 0;
                result = SCardListReadersW(context, null, null, ref size);
                bool hasReaders = (result == 0 && size > 0);

                if (hasReaders)
                {
                    byte[] readers = new byte[size * 2];
                    SCardListReadersW(context, null, readers, ref size);
                    string readerList = Encoding.Unicode.GetString(readers);
                    Log($"  Readers: {readerList.Replace('\0', '|')}");
                }

                SCardReleaseContext(context);
                return hasReaders;
            }
            catch { return false; }
        }

        // ============================================================
        // READ CARD
        // ============================================================
        static string ReadCard()
        {
            if (_slot < 0) return ERR("Nessuna carta rilevata - prima fai CHECK_READER");

            bool tx = false;
            try
            {
                Log($"ReadCard: slot={_slot}");

                int state = isCardIn(_slot);
                Log($"  isCardIn({_slot}) = {state} ({DecodeCardState(state)})");
                if (!IsCardPresent(state))
                {
                    _slot = -1;
                    return ERR("Carta rimossa");
                }

                int init = Initialize(_slot);
                Log($"  Initialize = {init}");

                int txResult = BeginTransactionML(_slot);
                Log($"  BeginTransactionML = {txResult}");
                tx = (txResult == 0);

                byte[] sn = new byte[8];
                int snResult = GetSNML(sn, _slot);
                Log($"  GetSNML = {snResult}, SN = {BitConverter.ToString(sn)}");

                if (snResult != 0)
                {
                    return ERR($"Lettura SN fallita: errore 0x{snResult:X4}");
                }

                uint cnt = 0, bal = 0;
                int cntResult = ReadCounterML(ref cnt, _slot);
                Log($"  ReadCounterML = {cntResult} (0x{cntResult:X4}), cnt = {cnt}");
                
                int balResult = ReadBalanceML(ref bal, _slot);
                Log($"  ReadBalanceML = {balResult} (0x{balResult:X4}), bal = {bal}");
                
                byte key = GetKeyIDML(_slot);
                Log($"  GetKeyIDML = {key}");

                Log($"  FINAL: Counter = {cnt}, Balance = {bal}, KeyID = {key}");

                // Anche se counter/balance falliscono, ritorniamo comunque i dati che abbiamo
                return JsonConvert.SerializeObject(new
                {
                    success = true,
                    serialNumber = BitConverter.ToString(sn).Replace("-", ""),
                    counter = cntResult == 0 ? (uint?)cnt : null,
                    balance = balResult == 0 ? (uint?)bal : null,
                    keyId = (int)key,
                    slot = _slot,
                    counterError = cntResult != 0 ? $"0x{cntResult:X4}" : null,
                    balanceError = balResult != 0 ? $"0x{balResult:X4}" : null
                });
            }
            catch (Exception ex)
            {
                Log($"ReadCard error: {ex.Message}");
                return ERR(ex.Message);
            }
            finally
            {
                if (tx)
                {
                    try
                    {
                        EndTransactionML(_slot);
                        Log("  EndTransactionML done");
                    }
                    catch { }
                }
            }
        }

        // ============================================================
        // READ EFFF - Legge file EFFF dalla Smart Card SIAE
        // Contiene 15 campi anagrafici (DF 11 11, EF FF)
        // Conforme a Descrizione_contenuto_SmartCardTestxBA-V102.pdf
        // ============================================================
        static string ReadEfff()
        {
            if (_slot < 0) return ERR("Nessuna carta rilevata - prima fai CHECK_READER");

            bool tx = false;
            try
            {
                Log($"ReadEfff: slot={_slot}");

                int state = isCardIn(_slot);
                Log($"  isCardIn({_slot}) = {state} ({DecodeCardState(state)})");
                if (!IsCardPresent(state))
                {
                    _slot = -1;
                    return ERR("Carta rimossa");
                }

                int init = Initialize(_slot);
                Log($"  Initialize = {init}");

                int txResult = BeginTransactionML(_slot);
                Log($"  BeginTransactionML = {txResult}");
                tx = (txResult == 0);

                // Navigate to DF PKI (0x1111) which contains EFFF
                int sel0000 = LibSiae.SelectML(0x0000, _slot);
                Log($"  SelectML(0x0000 root) = {sel0000} (0x{sel0000:X4})");
                
                int sel1111 = LibSiae.SelectML(0x1111, _slot);
                Log($"  SelectML(0x1111 DF PKI) = {sel1111} (0x{sel1111:X4})");
                
                // Select EF FF (anagrafica file) - File ID is 0xEFFF per SIAE documentation
                int selEFFF = LibSiae.SelectML(0xEFFF, _slot);
                Log($"  SelectML(0xEFFF EF FF) = {selEFFF} (0x{selEFFF:X4})");

                if (selEFFF != 0)
                {
                    // Fallback: try 0x00FF in case card uses alternative addressing
                    selEFFF = LibSiae.SelectML(0x00FF, _slot);
                    Log($"  SelectML(0x00FF alt) = {selEFFF} (0x{selEFFF:X4})");
                }

                // EFFF contains 15 variable-length records
                // Field lengths according to specification:
                // 1. systemId (8), 2. contactName (40), 3. contactLastName (40), 4. contactCodFis (18)
                // 5. systemLocation (100), 6. contactEmail (50), 7. siaeEmail (40)
                // 8. partnerName (60), 9. partnerCodFis (18), 10. partnerRegistroImprese (18)
                // 11. partnerNation (2), 12. systemApprCode (20), 13. systemApprDate (20)
                // 14. contactRepresentationType (1), 15. userDataFileVersion (5)

                var efffData = new
                {
                    systemId = ReadEfffField(1, 8),
                    contactName = ReadEfffField(2, 40),
                    contactLastName = ReadEfffField(3, 40),
                    contactCodFis = ReadEfffField(4, 18),
                    systemLocation = ReadEfffField(5, 100),
                    contactEmail = ReadEfffField(6, 50),
                    siaeEmail = ReadEfffField(7, 40),
                    partnerName = ReadEfffField(8, 60),
                    partnerCodFis = ReadEfffField(9, 18),
                    partnerRegistroImprese = ReadEfffField(10, 18),
                    partnerNation = ReadEfffField(11, 2),
                    systemApprCode = ReadEfffField(12, 20),
                    systemApprDate = ReadEfffField(13, 20),
                    contactRepresentationType = ReadEfffField(14, 1),
                    userDataFileVersion = ReadEfffField(15, 5)
                };

                Log($"  EFFF Data read: systemId={efffData.systemId}, siaeEmail={efffData.siaeEmail}");

                // Determine if test card based on systemId prefix
                bool isTestCard = !string.IsNullOrEmpty(efffData.systemId) && 
                                  efffData.systemId.ToUpper().StartsWith("P");

                return JsonConvert.SerializeObject(new
                {
                    success = true,
                    efffData = efffData,
                    isTestCard = isTestCard,
                    environment = isTestCard ? "test" : "production",
                    slot = _slot
                });
            }
            catch (Exception ex)
            {
                Log($"ReadEfff error: {ex.Message}");
                return ERR(ex.Message);
            }
            finally
            {
                if (tx)
                {
                    try
                    {
                        EndTransactionML(_slot);
                        Log("  EndTransactionML done");
                    }
                    catch { }
                }
            }
        }

        /// <summary>
        /// Read a single field from EFFF file by record number
        /// </summary>
        static string ReadEfffField(int recordNumber, int maxLen)
        {
            try
            {
                byte[] buffer = new byte[maxLen + 2]; // Extra bytes for safety
                int len = buffer.Length;
                
                int result = LibSiae.ReadRecordML(recordNumber, buffer, ref len, _slot);
                
                if (result != 0)
                {
                    Log($"    ReadRecordML({recordNumber}) = 0x{result:X4}, len={len}");
                    return "";
                }

                // Trim null bytes and convert to string
                string value = Encoding.ASCII.GetString(buffer, 0, len).TrimEnd('\0', ' ');
                Log($"    Record {recordNumber}: \"{value}\" (len={len})");
                return value;
            }
            catch (Exception ex)
            {
                Log($"    ReadEfffField({recordNumber}) error: {ex.Message}");
                return "";
            }
        }

        // ============================================================
        // GET CERTIFICATE - Legge certificato X.509 ed estrae email
        // Per identificare l'indirizzo SIAE di risposta
        // ============================================================
        static string GetCertificate()
        {
            if (_slot < 0) return ERR("Nessuna carta rilevata - prima fai CHECK_READER");

            bool tx = false;
            try
            {
                Log($"GetCertificate: slot={_slot}");

                int state = isCardIn(_slot);
                Log($"  isCardIn({_slot}) = {state} ({DecodeCardState(state)})");
                if (!IsCardPresent(state))
                {
                    _slot = -1;
                    return ERR("Carta rimossa");
                }

                int init = Initialize(_slot);
                Log($"  Initialize = {init}");

                int txResult = BeginTransactionML(_slot);
                Log($"  BeginTransactionML = {txResult}");
                tx = (txResult == 0);

                // Select DF PKI (0x1111) for certificate access
                int sel0000 = LibSiae.SelectML(0x0000, _slot);
                Log($"  SelectML(0x0000 root) = {sel0000} (0x{sel0000:X4})");
                
                int sel1111 = LibSiae.SelectML(0x1111, _slot);
                Log($"  SelectML(0x1111 DF PKI) = {sel1111} (0x{sel1111:X4})");

                // Get the certificate from the smart card
                byte[] cert = new byte[2048];
                int certLen = cert.Length;
                int certResult = LibSiae.GetCertificateML(cert, ref certLen, _slot);
                Log($"  GetCertificateML = {certResult}, certLen={certLen}");
                
                if (certResult != 0 || certLen == 0)
                {
                    return ERR($"Lettura certificato fallita: 0x{certResult:X4}");
                }

                byte[] actualCert = new byte[certLen];
                Array.Copy(cert, actualCert, certLen);

                // Parse X.509 certificate to extract email and other info
                string email = "";
                string commonName = "";
                string serialNumber = "";
                string issuer = "";
                string expiryDate = "";
                
                try
                {
                    var x509 = new System.Security.Cryptography.X509Certificates.X509Certificate2(actualCert);
                    commonName = x509.GetNameInfo(System.Security.Cryptography.X509Certificates.X509NameType.SimpleName, false) ?? "";
                    serialNumber = x509.SerialNumber ?? "";
                    issuer = x509.Issuer ?? "";
                    expiryDate = x509.NotAfter.ToString("yyyy-MM-dd");
                    
                    // Try to get email from Subject Alternative Name (SAN) extension
                    foreach (var ext in x509.Extensions)
                    {
                        if (ext.Oid?.Value == "2.5.29.17") // Subject Alternative Name OID
                        {
                            var sanString = ext.Format(false);
                            Log($"  SAN extension: {sanString}");
                            
                            // Look for RFC822 Name (email) in SAN
                            var match = System.Text.RegularExpressions.Regex.Match(sanString, @"RFC822[^=]*=([^\s,]+)");
                            if (match.Success)
                            {
                                email = match.Groups[1].Value;
                                Log($"  Found email in SAN: {email}");
                                break;
                            }
                            // Also try email: prefix
                            match = System.Text.RegularExpressions.Regex.Match(sanString, @"email:([^\s,]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                            if (match.Success)
                            {
                                email = match.Groups[1].Value;
                                Log($"  Found email in SAN (email:): {email}");
                                break;
                            }
                        }
                    }
                    
                    // Fallback: Try to get email from Subject (E= or EMAILADDRESS=)
                    if (string.IsNullOrEmpty(email))
                    {
                        var subject = x509.Subject;
                        Log($"  Subject: {subject}");
                        
                        var emailMatch = System.Text.RegularExpressions.Regex.Match(subject, @"(?:E=|EMAIL=|EMAILADDRESS=)([^,]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                        if (emailMatch.Success)
                        {
                            email = emailMatch.Groups[1].Value.Trim();
                            Log($"  Found email in Subject: {email}");
                        }
                    }
                    
                    Log($"  Certificate parsed: CN={commonName}, Email={email}, Expiry={expiryDate}");
                }
                catch (Exception certEx)
                {
                    Log($"  Certificate parsing error: {certEx.Message}");
                    return ERR($"Errore parsing certificato: {certEx.Message}");
                }

                return JsonConvert.SerializeObject(new
                {
                    success = true,
                    email = email,
                    commonName = commonName,
                    serialNumber = serialNumber,
                    issuer = issuer,
                    expiryDate = expiryDate,
                    certificateBase64 = Convert.ToBase64String(actualCert)
                });
            }
            catch (Exception ex)
            {
                Log($"GetCertificate error: {ex.Message}");
                return ERR(ex.Message);
            }
            finally
            {
                if (tx)
                {
                    try
                    {
                        EndTransactionML(_slot);
                        Log("  EndTransactionML done");
                    }
                    catch { }
                }
            }
        }

        // ============================================================
        // VERIFY PIN - Verifica PIN sulla carta SIAE
        // ============================================================
        static string VerifyPin(string pin)
        {
            if (_slot < 0) return ERR("Nessuna carta rilevata - prima fai CHECK_READER");

            // Pulisci il PIN: rimuovi spazi e caratteri non numerici
            pin = new string(pin.Where(char.IsDigit).ToArray());
            
            if (string.IsNullOrEmpty(pin) || pin.Length < 4)
            {
                return ERR("PIN non valido - deve contenere almeno 4 cifre");
            }

            bool tx = false;
            try
            {
                Log($"VerifyPin: slot={_slot}, pin={new string('*', pin.Length)} (length={pin.Length})");

                int state = isCardIn(_slot);
                Log($"  isCardIn({_slot}) = {state} ({DecodeCardState(state)})");
                if (!IsCardPresent(state))
                {
                    _slot = -1;
                    return ERR("Carta rimossa");
                }

                // Prima chiama Finalize per resettare lo stato della carta
                int finRes = FinalizeML(_slot);
                Log($"  FinalizeML = {finRes}");
                
                int init = Initialize(_slot);
                Log($"  Initialize = {init}");
                
                // Se Initialize non ritorna 0, la carta potrebbe essere in uno stato inconsistente
                // Questo può accadere se la sessione precedente non è stata chiusa correttamente
                if (init != 0)
                {
                    Log($"  Initialize returned {init}, trying to reset card state...");
                    FinalizeML(_slot);
                    System.Threading.Thread.Sleep(100);  // Breve pausa
                    init = Initialize(_slot);
                    Log($"  Initialize (2nd attempt) = {init}");
                }

                int txResult = BeginTransactionML(_slot);
                Log($"  BeginTransactionML = {txResult}");
                tx = (txResult == 0);

                // ========================================
                // SEQUENZA CORRETTA DA DOCUMENTAZIONE SIAE
                // ========================================
                // Per Sigillo Fiscale: SelectML(0x0000) -> SelectML(0x1112) -> VerifyPINML(1, pin)
                // Per PKI (firma):     SelectML(0x0000) -> SelectML(0x1111) -> VerifyPINML(1, pin)
                
                // 1. Seleziona root (0x0000)
                int sel0000 = LibSiae.SelectML(0x0000, _slot);
                Log($"  SelectML(0x0000 root) = {sel0000} (0x{sel0000:X4})");
                
                // 2. Seleziona DF Sigilli Fiscali (0x1112)
                int sel1112 = LibSiae.SelectML(0x1112, _slot);
                Log($"  SelectML(0x1112 DF Sigilli) = {sel1112} (0x{sel1112:X4})");
                
                // Se 0x1112 fallisce, prova 0x1111 (DF PKI)
                if (sel1112 != 0)
                {
                    int sel1111 = LibSiae.SelectML(0x1111, _slot);
                    Log($"  SelectML(0x1111 DF PKI) = {sel1111} (0x{sel1111:X4})");
                }
                
                // 3. Verifica PIN con nPIN=1 (dalla documentazione ufficiale)
                int pinResult = VerifyPINML(1, pin, _slot);
                Log($"  VerifyPINML(nPIN=1, pin=***) = {pinResult} (0x{pinResult:X4})");
                
                // Se nPIN=1 non funziona, proviamo altri valori
                if (pinResult != 0 && pinResult != 0x6983 && (pinResult < 0x63C0 || pinResult > 0x63CF))
                {
                    Log($"  nPIN=1 fallito, provo altri valori...");
                    int[] altNPin = { 0, 2, 0x81 };
                    foreach (int nPin in altNPin)
                    {
                        int res = VerifyPINML(nPin, pin, _slot);
                        Log($"  VerifyPINML(nPIN={nPin}) = {res} (0x{res:X4})");
                        if (res == 0 || res == 0x6983 || (res >= 0x63C0 && res <= 0x63CF))
                        {
                            pinResult = res;
                            break;
                        }
                    }
                }

                if (pinResult == 0)
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        verified = true,
                        message = "PIN verificato correttamente"
                    });
                }
                else if (pinResult == 0x6982)
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        verified = false,
                        error = "PIN errato",
                        errorCode = pinResult
                    });
                }
                else if (pinResult == 0x6983)
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        verified = false,
                        error = "PIN bloccato - troppi tentativi errati",
                        errorCode = pinResult
                    });
                }
                else
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        verified = false,
                        error = $"Errore verifica PIN: 0x{pinResult:X4}",
                        errorCode = pinResult
                    });
                }
            }
            catch (Exception ex)
            {
                Log($"VerifyPin error: {ex.Message}");
                return ERR(ex.Message);
            }
            finally
            {
                if (tx)
                {
                    try
                    {
                        EndTransactionML(_slot);
                        Log("  EndTransactionML done");
                    }
                    catch { }
                }
            }
        }

        // ============================================================
        // CHANGE PIN - Cambio PIN della carta SIAE
        // Formato: oldPin,newPin oppure pinNumber,oldPin,newPin
        // SIAE cards have PIN1 (nPIN=1) for Sigillo and PIN2 (nPIN=2) for PKI
        // ============================================================
        static string ChangePin(string args)
        {
            if (_slot < 0) return ERR("Nessuna carta rilevata - prima fai CHECK_READER");

            // Parse arguments: oldPin,newPin OR pinNumber,oldPin,newPin
            var parts = args.Split(',');
            int pinNumber = 1; // Default to PIN1 (Sigillo)
            string oldPin, newPin;

            if (parts.Length == 2)
            {
                oldPin = new string(parts[0].Where(char.IsDigit).ToArray());
                newPin = new string(parts[1].Where(char.IsDigit).ToArray());
            }
            else if (parts.Length == 3)
            {
                if (!int.TryParse(parts[0], out pinNumber) || (pinNumber != 1 && pinNumber != 2))
                {
                    return ERR("Numero PIN non valido - deve essere 1 (Sigillo) o 2 (PKI)");
                }
                oldPin = new string(parts[1].Where(char.IsDigit).ToArray());
                newPin = new string(parts[2].Where(char.IsDigit).ToArray());
            }
            else
            {
                return ERR("Formato: CHANGE_PIN:oldPin,newPin oppure CHANGE_PIN:pinNumber,oldPin,newPin");
            }

            if (oldPin.Length < 4 || oldPin.Length > 8)
            {
                return ERR("PIN attuale non valido - deve essere 4-8 cifre");
            }
            if (newPin.Length < 4 || newPin.Length > 8)
            {
                return ERR("Nuovo PIN non valido - deve essere 4-8 cifre");
            }

            bool tx = false;
            try
            {
                Log($"ChangePin: slot={_slot}, pinNumber={pinNumber}, oldPin=****, newPin=****");

                int state = isCardIn(_slot);
                if (!IsCardPresent(state))
                {
                    _slot = -1;
                    return ERR("Carta rimossa");
                }

                int finRes = FinalizeML(_slot);
                Log($"  FinalizeML = {finRes}");
                
                int init = Initialize(_slot);
                Log($"  Initialize = {init}");

                int txResult = BeginTransactionML(_slot);
                Log($"  BeginTransactionML = {txResult}");
                tx = (txResult == 0);

                // Select appropriate DF based on PIN number
                // PIN1 = DF Sigilli (0x1112), PIN2 = DF PKI (0x1111)
                int sel0000 = LibSiae.SelectML(0x0000, _slot);
                Log($"  SelectML(0x0000) = {sel0000}");
                
                int selDF;
                if (pinNumber == 1)
                {
                    selDF = LibSiae.SelectML(0x1112, _slot);
                    Log($"  SelectML(0x1112 DF Sigilli) = {selDF}");
                }
                else
                {
                    selDF = LibSiae.SelectML(0x1111, _slot);
                    Log($"  SelectML(0x1111 DF PKI) = {selDF}");
                }

                // Change PIN
                int result = LibSiae.ChangePINML(pinNumber, oldPin, newPin, _slot);
                Log($"  ChangePINML(nPIN={pinNumber}) = {result} (0x{result:X4})");

                // Decode retries from error code 0x63CX
                int? retriesRemaining = null;
                if (result >= 0x63C0 && result <= 0x63CF)
                {
                    retriesRemaining = result & 0x0F;
                    Log($"  Retries remaining: {retriesRemaining}");
                }

                if (result == 0)
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        changed = true,
                        pinNumber = pinNumber,
                        message = $"PIN{pinNumber} cambiato con successo"
                    });
                }
                else if (result == 0x6983)
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        changed = false,
                        pinNumber = pinNumber,
                        error = $"PIN{pinNumber} bloccato - usare PUK per sbloccare",
                        errorCode = result,
                        retriesRemaining = 0
                    });
                }
                else if (result == 0x6982 || (result >= 0x63C0 && result <= 0x63CF))
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        changed = false,
                        pinNumber = pinNumber,
                        error = "PIN attuale errato",
                        errorCode = result,
                        retriesRemaining = retriesRemaining
                    });
                }
                else
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        changed = false,
                        pinNumber = pinNumber,
                        error = $"Errore cambio PIN{pinNumber}: 0x{result:X4} - {LibSiae.GetErrorMessage(result)}",
                        errorCode = result
                    });
                }
            }
            catch (Exception ex)
            {
                Log($"ChangePin error: {ex.Message}");
                return ERR(ex.Message);
            }
            finally
            {
                if (tx)
                {
                    try
                    {
                        EndTransactionML(_slot);
                        Log("  EndTransactionML done");
                    }
                    catch { }
                }
            }
        }

        // ============================================================
        // UNLOCK PUK - Sblocco carta con PUK
        // Formato: puk,newPin oppure pinNumber,puk,newPin
        // SIAE cards have PIN1 (nPIN=1) for Sigillo and PIN2 (nPIN=2) for PKI
        // PUK is used to unlock blocked PINs and set a new PIN
        // ============================================================
        static string UnlockPuk(string args)
        {
            if (_slot < 0) return ERR("Nessuna carta rilevata - prima fai CHECK_READER");

            // Parse arguments: puk,newPin OR pinNumber,puk,newPin
            var parts = args.Split(',');
            int pinNumber = 1; // Default to PIN1 (Sigillo)
            string puk, newPin;

            if (parts.Length == 2)
            {
                puk = new string(parts[0].Where(char.IsDigit).ToArray());
                newPin = new string(parts[1].Where(char.IsDigit).ToArray());
            }
            else if (parts.Length == 3)
            {
                if (!int.TryParse(parts[0], out pinNumber) || (pinNumber != 1 && pinNumber != 2))
                {
                    return ERR("Numero PIN non valido - deve essere 1 (Sigillo) o 2 (PKI)");
                }
                puk = new string(parts[1].Where(char.IsDigit).ToArray());
                newPin = new string(parts[2].Where(char.IsDigit).ToArray());
            }
            else
            {
                return ERR("Formato: UNLOCK_PUK:puk,newPin oppure UNLOCK_PUK:pinNumber,puk,newPin");
            }

            if (puk.Length != 8)
            {
                return ERR("PUK non valido - deve essere esattamente 8 cifre");
            }
            if (newPin.Length < 4 || newPin.Length > 8)
            {
                return ERR("Nuovo PIN non valido - deve essere 4-8 cifre");
            }

            bool tx = false;
            try
            {
                Log($"UnlockPuk: slot={_slot}, pinNumber={pinNumber}, puk=********, newPin=****");

                int state = isCardIn(_slot);
                if (!IsCardPresent(state))
                {
                    _slot = -1;
                    return ERR("Carta rimossa");
                }

                int finRes = FinalizeML(_slot);
                Log($"  FinalizeML = {finRes}");
                
                int init = Initialize(_slot);
                Log($"  Initialize = {init}");

                int txResult = BeginTransactionML(_slot);
                Log($"  BeginTransactionML = {txResult}");
                tx = (txResult == 0);

                // Select appropriate DF based on PIN number
                // PIN1 = DF Sigilli (0x1112), PIN2 = DF PKI (0x1111)
                int sel0000 = LibSiae.SelectML(0x0000, _slot);
                Log($"  SelectML(0x0000) = {sel0000}");
                
                int selDF;
                if (pinNumber == 1)
                {
                    selDF = LibSiae.SelectML(0x1112, _slot);
                    Log($"  SelectML(0x1112 DF Sigilli) = {selDF}");
                }
                else
                {
                    selDF = LibSiae.SelectML(0x1111, _slot);
                    Log($"  SelectML(0x1111 DF PKI) = {selDF}");
                }

                // Unlock PIN with PUK
                int result = LibSiae.UnblockPINML(pinNumber, puk, newPin, _slot);
                Log($"  UnblockPINML(nPIN={pinNumber}) = {result} (0x{result:X4})");

                // Decode retries from error code 0x63CX
                int? pukRetriesRemaining = null;
                if (result >= 0x63C0 && result <= 0x63CF)
                {
                    pukRetriesRemaining = result & 0x0F;
                    Log($"  PUK retries remaining: {pukRetriesRemaining}");
                }

                if (result == 0)
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        unlocked = true,
                        pinNumber = pinNumber,
                        message = $"PIN{pinNumber} sbloccato con successo - nuovo PIN impostato"
                    });
                }
                else if (result == 0x6983)
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        unlocked = false,
                        pinNumber = pinNumber,
                        error = "PUK bloccato - carta non recuperabile, contattare SIAE per sostituzione",
                        errorCode = result,
                        pukRetriesRemaining = 0
                    });
                }
                else if (result == 0x6982 || (result >= 0x63C0 && result <= 0x63CF))
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        unlocked = false,
                        pinNumber = pinNumber,
                        error = "PUK errato",
                        errorCode = result,
                        pukRetriesRemaining = pukRetriesRemaining
                    });
                }
                else
                {
                    return JsonConvert.SerializeObject(new
                    {
                        success = true,
                        unlocked = false,
                        pinNumber = pinNumber,
                        error = $"Errore sblocco PIN{pinNumber}: 0x{result:X4} - {LibSiae.GetErrorMessage(result)}",
                        errorCode = result
                    });
                }
            }
            catch (Exception ex)
            {
                Log($"UnlockPuk error: {ex.Message}");
                return ERR(ex.Message);
            }
            finally
            {
                if (tx)
                {
                    try
                    {
                        EndTransactionML(_slot);
                        Log("  EndTransactionML done");
                    }
                    catch { }
                }
            }
        }

        // ============================================================
        // GET RETRIES - Ottieni tentativi PIN/PUK rimasti
        // ============================================================
        static string GetRetries()
        {
            if (_slot < 0) return ERR("Nessuna carta rilevata - prima fai CHECK_READER");

            bool tx = false;
            try
            {
                Log($"GetRetries: slot={_slot}");

                int state = isCardIn(_slot);
                if (!IsCardPresent(state))
                {
                    _slot = -1;
                    return ERR("Carta rimossa");
                }

                int init = Initialize(_slot);
                Log($"  Initialize = {init}");

                int txResult = BeginTransactionML(_slot);
                Log($"  BeginTransactionML = {txResult}");
                tx = (txResult == 0);

                // Le carte SIAE non hanno un comando diretto per leggere i tentativi rimasti.
                // Il numero di tentativi viene restituito come parte del codice errore 0x63CX
                // dove X è il numero di tentativi rimasti.
                // Per ora, restituiamo valori default (3 per PIN, 10 per PUK tipicamente)
                // In futuro si potrebbe provare a verificare un PIN vuoto per ottenere il counter.

                return JsonConvert.SerializeObject(new
                {
                    success = true,
                    pinRetries = 3,  // Valore default, non leggibile direttamente
                    pukRetries = 10, // Valore default, non leggibile direttamente
                    message = "Tentativi stimati (valori standard carte SIAE)"
                });
            }
            catch (Exception ex)
            {
                Log($"GetRetries error: {ex.Message}");
                return ERR(ex.Message);
            }
            finally
            {
                if (tx)
                {
                    try
                    {
                        EndTransactionML(_slot);
                        Log("  EndTransactionML done");
                    }
                    catch { }
                }
            }
        }

        // ============================================================
        // COMPUTE SIGILLO
        // ============================================================
        static string ComputeSigillo(string json)
        {
            if (_slot < 0) return ERR("Nessuna carta");

            bool tx = false;
            try
            {
                dynamic req = JsonConvert.DeserializeObject(json);
                decimal price = req.price;
                string pin = req.pin;  // Get PIN from request

                int state = isCardIn(_slot);
                if (!IsCardPresent(state)) { _slot = -1; return ERR("Carta rimossa"); }

                Initialize(_slot);
                BeginTransactionML(_slot);
                tx = true;

                // ========================================
                // PIN VERIFICATION BEFORE SEAL (required by SIAE cards)
                // Sequence from official test.c: SelectML(0x0000) -> SelectML(0x1112) -> SelectML(0x1000) -> VerifyPINML(1, pin)
                // Error 0x6982 = "Security status not satisfied" = C_NOT_AUTHORIZED
                // ========================================
                if (!string.IsNullOrEmpty(pin))
                {
                    Log($"  PIN provided, verifying before seal (SIAE sequence)...");
                    
                    // Clean PIN
                    pin = new string(pin.Where(char.IsDigit).ToArray());
                    
                    // SIAE official sequence from test.c (lines 220-234):
                    // 1. Select root DF (0x0000)
                    int sel0000 = LibSiae.SelectML(0x0000, _slot);
                    Log($"  SelectML(0x0000 root) = {sel0000} (0x{sel0000:X4})");
                    
                    // 2. Select DF Sigilli Fiscali (0x1112)
                    int sel1112 = LibSiae.SelectML(0x1112, _slot);
                    Log($"  SelectML(0x1112 DF Sigilli) = {sel1112} (0x{sel1112:X4})");
                    
                    // 3. Select EF (0x1000) - from performance test in official docs
                    int sel1000 = LibSiae.SelectML(0x1000, _slot);
                    Log($"  SelectML(0x1000 EF) = {sel1000} (0x{sel1000:X4})");
                    
                    // 4. Verify PIN with nPIN=1 (from official docs)
                    int pinResult = VerifyPINML(1, pin, _slot);
                    Log($"  VerifyPINML(nPIN=1) = {pinResult} (0x{pinResult:X4})");
                    
                    if (pinResult != 0)
                    {
                        if (pinResult == 0x6983)
                            return ERR("PIN bloccato - troppi tentativi errati");
                        else if (pinResult == 0x6982)
                            return ERR("PIN errato - autenticazione fallita");
                        else if (pinResult >= 0x63C0 && pinResult <= 0x63CF)
                            return ERR($"PIN errato - tentativi rimasti: {pinResult & 0x0F}");
                        else
                            return ERR($"Verifica PIN fallita: 0x{pinResult:X4}");
                    }
                    Log($"  ✓ PIN verified successfully before seal");
                }
                else
                {
                    Log($"  WARNING: No PIN provided, seal may fail with 0x6982");
                }

                DateTime dt = DateTime.Now;
                byte[] bcd = new byte[5];
                int y = dt.Year % 100;
                bcd[0] = (byte)(((y / 10) << 4) | (y % 10));
                bcd[1] = (byte)(((dt.Month / 10) << 4) | (dt.Month % 10));
                bcd[2] = (byte)(((dt.Day / 10) << 4) | (dt.Day % 10));
                bcd[3] = (byte)(((dt.Hour / 10) << 4) | (dt.Hour % 10));
                bcd[4] = (byte)(((dt.Minute / 10) << 4) | (dt.Minute % 10));

                uint cents = (uint)(price * 100);
                byte[] sn = new byte[8], mac = new byte[8];
                uint cnt = 0;

                Log($"ComputeSigilloML: price={cents} cents");
                int r = ComputeSigilloML(bcd, cents, sn, mac, ref cnt, _slot);
                Log($"  Result = {r} (0x{r:X4})");

                if (r != 0) return ERR($"Sigillo fallito: errore 0x{r:X4}");

                return JsonConvert.SerializeObject(new
                {
                    success = true,
                    sigillo = new
                    {
                        serialNumber = BitConverter.ToString(sn).Replace("-", ""),
                        mac = BitConverter.ToString(mac).Replace("-", ""),
                        counter = cnt,
                        dateTime = dt.ToString("yyyy-MM-dd HH:mm"),
                        price = price
                    }
                });
            }
            catch (Exception ex)
            {
                Log($"ComputeSigillo error: {ex.Message}");
                return ERR(ex.Message);
            }
            finally
            {
                if (tx) try { EndTransactionML(_slot); } catch { }
            }
        }

        // ============================================================
        // SIGN XML - Firma digitale CAdES-BES con SHA-256
        // Produce file P7M conforme ai requisiti SIAE
        // Usato per i report C1 da inviare a SIAE
        // ============================================================
        static string SignXml(string json)
        {
            if (_slot < 0) return ERR("Nessuna carta rilevata - prima fai CHECK_READER");

            bool tx = false;
            try
            {
                dynamic req = JsonConvert.DeserializeObject(json);
                string xmlContent = req.xmlContent;
                string pin = req.pin;

                if (string.IsNullOrEmpty(xmlContent))
                {
                    return ERR("Contenuto XML mancante");
                }

                Log($"SignXml (CAdES-BES): slot={_slot}, xmlLength={xmlContent?.Length ?? 0}");

                int state = isCardIn(_slot);
                if (!IsCardPresent(state))
                {
                    _slot = -1;
                    return ERR("Carta rimossa");
                }

                // Initialize and begin transaction
                int finRes = FinalizeML(_slot);
                Log($"  FinalizeML = {finRes}");
                
                int init = Initialize(_slot);
                Log($"  Initialize = {init}");

                int txResult = BeginTransactionML(_slot);
                Log($"  BeginTransactionML = {txResult}");
                tx = (txResult == 0);

                // Select DF PKI (0x1111) for signature operations
                int sel0000 = LibSiae.SelectML(0x0000, _slot);
                Log($"  SelectML(0x0000 root) = {sel0000} (0x{sel0000:X4})");
                
                int sel1111 = LibSiae.SelectML(0x1111, _slot);
                Log($"  SelectML(0x1111 DF PKI) = {sel1111} (0x{sel1111:X4})");

                // Verify PIN if provided (using libSIAE to unlock the card)
                if (!string.IsNullOrEmpty(pin))
                {
                    pin = new string(pin.Where(char.IsDigit).ToArray());
                    int pinResult = VerifyPINML(1, pin, _slot);
                    Log($"  VerifyPINML(nPIN=1) = {pinResult} (0x{pinResult:X4})");
                    
                    if (pinResult != 0)
                    {
                        if (pinResult == 0x6983)
                            return ERR("PIN bloccato - troppi tentativi errati");
                        else if (pinResult == 0x6982)
                            return ERR("PIN errato - autenticazione fallita");
                        else if (pinResult >= 0x63C0 && pinResult <= 0x63CF)
                            return ERR($"PIN errato - tentativi rimasti: {pinResult & 0x0F}");
                        else
                            return ERR($"Verifica PIN fallita: 0x{pinResult:X4}");
                    }
                    Log($"  ✓ PIN verified successfully for signature");
                }
                else
                {
                    Log($"  WARNING: No PIN provided for signature operation");
                }

                // Convert XML to UTF-8 bytes
                byte[] xmlBytes = Encoding.UTF8.GetBytes(xmlContent);
                Log($"  XML bytes: {xmlBytes.Length}");

                // ============================================================
                // CAdES-BES con SHA-256 usando BouncyCastle
                // SIAE 2025: Solo CAdES-BES con SHA-256 è accettato
                // NO FALLBACK a XMLDSig/SHA-1 (deprecato e rifiutato da SIAE)
                // ============================================================
                Log($"  Creating CAdES-BES signature with BouncyCastle (SHA-256)...");
                Log($"  NOTE: NO fallback to legacy SHA-1/XMLDSig - SIAE requires SHA-256 only");
                var (success, p7mBase64, error, signedAt) = CreateCAdESSignatureBC(xmlBytes, pin);

                if (!success)
                {
                    Log($"  ERROR: CAdES-BES signature failed: {error}");
                    Log($"  CRITICAL: Cannot use legacy SHA-1 fallback - SIAE 2025 requires SHA-256");
                    // NO FALLBACK - Return error instead of using deprecated SHA-1
                    return ERR($"Firma CAdES-BES fallita: {error}. SIAE richiede SHA-256, fallback SHA-1 disabilitato.");
                }

                Log($"  ✓ CAdES-BES SHA-256 signature created successfully (SIAE 2025 compliant)");

                // Ritorna il P7M in formato Base64
                // Il server web salverà questo come file binario .p7m
                // NOTA: NON includere xmlContent per evitare che venga salvato al posto del P7M
                return JsonConvert.SerializeObject(new
                {
                    success = true,
                    signature = new
                    {
                        p7mBase64 = p7mBase64,           // File P7M firmato (CAdES-BES)
                        signedAt = signedAt,
                        format = "CAdES-BES",            // Formato firma
                        algorithm = "SHA-256"            // Algoritmo hash
                    }
                });
            }
            catch (Exception ex)
            {
                Log($"SignXml error: {ex.Message}");
                return ERR(ex.Message);
            }
            finally
            {
                if (tx)
                {
                    try
                    {
                        EndTransactionML(_slot);
                        Log("  EndTransactionML done");
                    }
                    catch { }
                }
            }
        }

        // ============================================================
        // Helper: Create XML-DSig signed document
        // ============================================================
        static string CreateSignedXml(string xmlContent, string signatureValue, string certificateData, string digestValue, string signedAt)
        {
            // Find the position before the closing root tag to insert the signature
            // For SIAE C1 reports, the root tag is typically <ComunicazioneDatiTitoli> or <RiepilogoMensile>
            int closingTagPos = xmlContent.LastIndexOf("</");
            
            if (closingTagPos < 0)
            {
                // If no closing tag found, append signature at the end
                return xmlContent + CreateSignatureBlock(signatureValue, certificateData, digestValue, signedAt);
            }

            // Insert XML-DSig signature before the closing root tag
            string signatureBlock = CreateSignatureBlock(signatureValue, certificateData, digestValue, signedAt);
            return xmlContent.Substring(0, closingTagPos) + signatureBlock + xmlContent.Substring(closingTagPos);
        }

        static string CreateSignatureBlock(string signatureValue, string certificateData, string digestValue, string signedAt)
        {
            // XML Digital Signature (XML-DSig) format per SIAE
            return $@"
  <Signature xmlns=""http://www.w3.org/2000/09/xmldsig#"">
    <SignedInfo>
      <CanonicalizationMethod Algorithm=""http://www.w3.org/TR/2001/REC-xml-c14n-20010315""/>
      <SignatureMethod Algorithm=""http://www.w3.org/2000/09/xmldsig#rsa-sha1""/>
      <Reference URI="""">
        <Transforms>
          <Transform Algorithm=""http://www.w3.org/2000/09/xmldsig#enveloped-signature""/>
        </Transforms>
        <DigestMethod Algorithm=""http://www.w3.org/2000/09/xmldsig#sha1""/>
        <DigestValue>{digestValue}</DigestValue>
      </Reference>
    </SignedInfo>
    <SignatureValue>{signatureValue}</SignatureValue>
    <KeyInfo>
      <X509Data>
        <X509Certificate>{certificateData}</X509Certificate>
      </X509Data>
    </KeyInfo>
    <Object>
      <SignatureProperties>
        <SignatureProperty Target=""#signature"">
          <SigningTime>{signedAt}</SigningTime>
        </SignatureProperty>
      </SignatureProperties>
    </Object>
  </Signature>";
        }

        // ============================================================
        // CAdES-BES SIGNATURE con BouncyCastle - SHA-256
        // Nuova implementazione che usa BouncyCastle per costruire la struttura CMS
        // con firma RSA dalla smart card SIAE
        // ============================================================

        /// <summary>
        /// Crea firma CAdES-BES usando BouncyCastle con SHA-256
        /// La firma RSA viene eseguita dalla smart card tramite LibSiae.SignML
        /// Ritorna il file P7M firmato in Base64
        /// </summary>
        static (bool success, string p7mBase64, string error, string signedAt) CreateCAdESSignatureBC(byte[] xmlBytes, string pin)
        {
            try
            {
                Log($"CreateCAdESSignatureBC: xmlBytes.Length={xmlBytes.Length}, slot={_slot}");
                string signedAt = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");

                // ============================================================
                // STEP 1: Leggi il certificato dalla smart card
                // ============================================================
                Log($"  Step 1: Reading certificate from smart card...");
                byte[] certBuffer = new byte[2048];
                int certLen = certBuffer.Length;
                int certResult = LibSiae.GetCertificateML(certBuffer, ref certLen, _slot);
                Log($"  GetCertificateML = {certResult} (0x{certResult:X4}), certLen={certLen}");

                if (certResult != 0 || certLen == 0)
                {
                    return (false, null, $"Lettura certificato fallita: 0x{certResult:X4}", null);
                }

                byte[] certBytes = new byte[certLen];
                Array.Copy(certBuffer, certBytes, certLen);

                // Parse certificate with BouncyCastle
                BCX509.X509Certificate bcCert;
                try
                {
                    X509CertificateParser certParser = new X509CertificateParser();
                    bcCert = certParser.ReadCertificate(certBytes);
                    Log($"  ✓ Certificate parsed: Subject={bcCert.SubjectDN}");
                }
                catch (Exception certEx)
                {
                    Log($"  Certificate parsing error: {certEx.Message}");
                    return (false, null, $"Errore parsing certificato: {certEx.Message}", null);
                }

                // ============================================================
                // STEP 2: Get KeyID from smart card
                // ============================================================
                Log($"  Step 2: Getting KeyID from smart card...");
                byte keyId = LibSiae.GetKeyIDML(_slot);
                Log($"  GetKeyIDML = {keyId} (0x{keyId:X2})");

                if (keyId == 0)
                {
                    return (false, null, "GetKeyID ha restituito 0 - nessuna chiave di firma disponibile", null);
                }

                // ============================================================
                // STEP 3: Calculate SHA-256 hash of the content (for messageDigest)
                // ============================================================
                Log($"  Step 3: Calculating SHA-256 hash of content...");
                Sha256Digest contentDigest = new Sha256Digest();
                contentDigest.BlockUpdate(xmlBytes, 0, xmlBytes.Length);
                byte[] contentHash = new byte[contentDigest.GetDigestSize()];
                contentDigest.DoFinal(contentHash, 0);
                Log($"  Content SHA-256: {BitConverter.ToString(contentHash).Replace("-", "").Substring(0, 32)}...");

                // ============================================================
                // STEP 4: Build signedAttributes (CAdES-BES requires specific attributes)
                // ============================================================
                Log($"  Step 4: Building signedAttributes...");
                
                // ContentType attribute (id-data = 1.2.840.113549.1.7.1)
                Asn1EncodableVector contentTypeAttr = new Asn1EncodableVector();
                contentTypeAttr.Add(CmsAttributes.ContentType);
                contentTypeAttr.Add(new DerSet(CmsObjectIdentifiers.Data));
                
                // Signing time attribute
                Asn1EncodableVector signingTimeAttr = new Asn1EncodableVector();
                signingTimeAttr.Add(CmsAttributes.SigningTime);
                signingTimeAttr.Add(new DerSet(new Org.BouncyCastle.Asn1.Cms.Time(DateTime.UtcNow)));
                
                // Message digest attribute (hash of content)
                Asn1EncodableVector messageDigestAttr = new Asn1EncodableVector();
                messageDigestAttr.Add(CmsAttributes.MessageDigest);
                messageDigestAttr.Add(new DerSet(new DerOctetString(contentHash)));

                // ============================================================
                // SigningCertificateV2 attribute - MANDATORY for CAdES-BES
                // Per ETSI EN 319 122-1 §6.2.1
                // OID: 1.2.840.113549.1.9.16.2.47
                // ============================================================
                Log($"  Building SigningCertificateV2 attribute...");
                
                // Calculate SHA-256 hash of the certificate
                Sha256Digest certDigest = new Sha256Digest();
                certDigest.BlockUpdate(certBytes, 0, certBytes.Length);
                byte[] certHash = new byte[certDigest.GetDigestSize()];
                certDigest.DoFinal(certHash, 0);
                Log($"  Certificate SHA-256: {BitConverter.ToString(certHash).Replace("-", "").Substring(0, 32)}...");

                // Build ESSCertIDv2 structure:
                // ESSCertIDv2 ::= SEQUENCE {
                //   hashAlgorithm AlgorithmIdentifier DEFAULT sha256,
                //   certHash      OCTET STRING,
                //   issuerSerial  IssuerSerial OPTIONAL
                // }
                // When hashAlgorithm is SHA-256 (default), it can be omitted
                
                // Build IssuerSerial (optional but recommended)
                // IssuerSerial ::= SEQUENCE { issuer GeneralNames, serialNumber CertificateSerialNumber }
                Asn1EncodableVector generalNamesVector = new Asn1EncodableVector();
                generalNamesVector.Add(new Org.BouncyCastle.Asn1.X509.GeneralName(
                    Org.BouncyCastle.Asn1.X509.GeneralName.DirectoryName, 
                    bcCert.IssuerDN
                ));
                Org.BouncyCastle.Asn1.X509.GeneralNames issuerGeneralNames = 
                    new Org.BouncyCastle.Asn1.X509.GeneralNames(
                        new Org.BouncyCastle.Asn1.X509.GeneralName(
                            Org.BouncyCastle.Asn1.X509.GeneralName.DirectoryName, 
                            bcCert.IssuerDN
                        )
                    );
                
                // IssuerSerial sequence
                Asn1EncodableVector issuerSerialVector = new Asn1EncodableVector();
                issuerSerialVector.Add(issuerGeneralNames);
                issuerSerialVector.Add(new DerInteger(bcCert.SerialNumber));
                DerSequence issuerSerial = new DerSequence(issuerSerialVector);
                
                // ESSCertIDv2 - SHA-256 is default so we can omit hashAlgorithm
                // Structure: SEQUENCE { certHash OCTET STRING, issuerSerial IssuerSerial OPTIONAL }
                Asn1EncodableVector essCertIdV2Vector = new Asn1EncodableVector();
                essCertIdV2Vector.Add(new DerOctetString(certHash));
                essCertIdV2Vector.Add(issuerSerial);
                DerSequence essCertIdV2 = new DerSequence(essCertIdV2Vector);
                
                // SigningCertificateV2 ::= SEQUENCE { certs SEQUENCE OF ESSCertIDv2 }
                Asn1EncodableVector certsSequence = new Asn1EncodableVector();
                certsSequence.Add(essCertIdV2);
                DerSequence signingCertV2 = new DerSequence(new DerSequence(certsSequence));
                
                // SigningCertificateV2 attribute
                DerObjectIdentifier signingCertV2Oid = new DerObjectIdentifier("1.2.840.113549.1.9.16.2.47");
                Asn1EncodableVector signingCertV2Attr = new Asn1EncodableVector();
                signingCertV2Attr.Add(signingCertV2Oid);
                signingCertV2Attr.Add(new DerSet(signingCertV2));
                Log($"  ✓ SigningCertificateV2 attribute built");

                // Combine all signed attributes
                Asn1EncodableVector signedAttrsVector = new Asn1EncodableVector();
                signedAttrsVector.Add(new DerSequence(contentTypeAttr));
                signedAttrsVector.Add(new DerSequence(signingTimeAttr));
                signedAttrsVector.Add(new DerSequence(messageDigestAttr));
                signedAttrsVector.Add(new DerSequence(signingCertV2Attr)); // CAdES-BES mandatory
                
                DerSet signedAttrs = new DerSet(signedAttrsVector);
                byte[] signedAttrsEncoded = signedAttrs.GetDerEncoded();
                Log($"  SignedAttributes encoded: {signedAttrsEncoded.Length} bytes");

                // ============================================================
                // STEP 5: Calculate SHA-256 hash of signedAttributes (for signature)
                // ============================================================
                Log($"  Step 5: Calculating SHA-256 hash of signedAttributes...");
                Sha256Digest attrsDigest = new Sha256Digest();
                attrsDigest.BlockUpdate(signedAttrsEncoded, 0, signedAttrsEncoded.Length);
                byte[] attrsHash = new byte[attrsDigest.GetDigestSize()];
                attrsDigest.DoFinal(attrsHash, 0);
                Log($"  SignedAttrs SHA-256: {BitConverter.ToString(attrsHash).Replace("-", "").Substring(0, 32)}...");

                // ============================================================
                // STEP 6: Apply PKCS#1 v1.5 padding with SHA-256 DigestInfo
                // DigestInfo ::= SEQUENCE { AlgorithmIdentifier, OCTET STRING digest }
                // SHA-256 OID: 2.16.840.1.101.3.4.2.1
                // ============================================================
                Log($"  Step 6: Building DigestInfo and applying PKCS#1 padding...");
                
                // Build DigestInfo for SHA-256
                Org.BouncyCastle.Asn1.X509.AlgorithmIdentifier sha256AlgId = new Org.BouncyCastle.Asn1.X509.AlgorithmIdentifier(
                    new DerObjectIdentifier("2.16.840.1.101.3.4.2.1"), // SHA-256 OID
                    DerNull.Instance
                );
                DigestInfo digestInfo = new DigestInfo(sha256AlgId, attrsHash);
                byte[] digestInfoEncoded = digestInfo.GetDerEncoded();
                Log($"  DigestInfo encoded: {digestInfoEncoded.Length} bytes");

                // PKCS#1 v1.5 padding: 0x00 0x01 [0xFF...] 0x00 [DigestInfo]
                // For RSA 1024-bit: block size = 128 bytes
                int keySize = 128; // RSA 1024-bit = 128 bytes
                byte[] paddedDigest = new byte[keySize];
                
                // Build padding: 0x00 0x01 FF...FF 0x00 DigestInfo
                paddedDigest[0] = 0x00;
                paddedDigest[1] = 0x01;
                int ffLength = keySize - 3 - digestInfoEncoded.Length;
                for (int i = 0; i < ffLength; i++)
                {
                    paddedDigest[2 + i] = 0xFF;
                }
                paddedDigest[2 + ffLength] = 0x00;
                Array.Copy(digestInfoEncoded, 0, paddedDigest, 3 + ffLength, digestInfoEncoded.Length);
                
                Log($"  PKCS#1 padded digest: {paddedDigest.Length} bytes, first bytes: {BitConverter.ToString(paddedDigest, 0, 4)}");

                // ============================================================
                // STEP 7: Sign with smart card using LibSiae.SignML
                // ============================================================
                Log($"  Step 7: Signing with smart card (keyId={keyId})...");
                byte[] signature = new byte[128]; // RSA 1024-bit signature
                int signResult = LibSiae.SignML(keyId, paddedDigest, signature, _slot);
                Log($"  SignML = {signResult} (0x{signResult:X4})");

                if (signResult != 0)
                {
                    string signError = signResult switch
                    {
                        0x6983 => "PIN bloccato - troppi tentativi errati",
                        0x6982 => "Non autorizzato - verificare PIN prima della firma",
                        _ when signResult >= 0x63C0 && signResult <= 0x63CF => $"PIN errato - tentativi rimasti: {signResult & 0x0F}",
                        _ => $"Firma fallita: 0x{signResult:X4}"
                    };
                    return (false, null, signError, null);
                }
                Log($"  ✓ Smart card signature: {signature.Length} bytes");

                // ============================================================
                // STEP 8: Build CMS SignedData structure using BouncyCastle
                // ============================================================
                Log($"  Step 8: Building CMS SignedData structure...");
                
                // SignerIdentifier (IssuerAndSerialNumber)
                Org.BouncyCastle.Asn1.Cms.IssuerAndSerialNumber issuerAndSerial = new Org.BouncyCastle.Asn1.Cms.IssuerAndSerialNumber(
                    bcCert.IssuerDN,
                    bcCert.SerialNumber
                );
                SignerIdentifier signerIdentifier = new SignerIdentifier(issuerAndSerial);

                // DigestAlgorithm (SHA-256)
                Org.BouncyCastle.Asn1.X509.AlgorithmIdentifier digestAlgorithm = new Org.BouncyCastle.Asn1.X509.AlgorithmIdentifier(
                    new DerObjectIdentifier("2.16.840.1.101.3.4.2.1"), // SHA-256
                    DerNull.Instance
                );

                // SignatureAlgorithm (RSA with SHA-256)
                Org.BouncyCastle.Asn1.X509.AlgorithmIdentifier signatureAlgorithm = new Org.BouncyCastle.Asn1.X509.AlgorithmIdentifier(
                    new DerObjectIdentifier("1.2.840.113549.1.1.11"), // sha256WithRSAEncryption
                    DerNull.Instance
                );

                // Build SignerInfo
                Org.BouncyCastle.Asn1.Cms.SignerInfo signerInfo = new Org.BouncyCastle.Asn1.Cms.SignerInfo(
                    signerIdentifier,
                    digestAlgorithm,
                    signedAttrs,           // signedAttrs (authenticated attributes)
                    signatureAlgorithm,
                    new DerOctetString(signature),
                    null                   // unsignedAttrs (none for CAdES-BES)
                );

                // Build ContentInfo (encapsulated content)
                Org.BouncyCastle.Asn1.Cms.ContentInfo encapContentInfo = new Org.BouncyCastle.Asn1.Cms.ContentInfo(
                    CmsObjectIdentifiers.Data,
                    new DerOctetString(xmlBytes)
                );

                // Build SignedData
                Asn1EncodableVector digestAlgorithms = new Asn1EncodableVector();
                digestAlgorithms.Add(digestAlgorithm);

                Asn1EncodableVector certificates = new Asn1EncodableVector();
                certificates.Add(bcCert.CertificateStructure);

                Asn1EncodableVector signerInfos = new Asn1EncodableVector();
                signerInfos.Add(signerInfo);

                Org.BouncyCastle.Asn1.Cms.SignedData signedData = new Org.BouncyCastle.Asn1.Cms.SignedData(
                    new DerSet(digestAlgorithms),
                    encapContentInfo,
                    new BerSet(certificates),
                    null, // CRLs
                    new DerSet(signerInfos)
                );

                // Wrap in ContentInfo (PKCS#7 container)
                Org.BouncyCastle.Asn1.Cms.ContentInfo pkcs7ContentInfo = new Org.BouncyCastle.Asn1.Cms.ContentInfo(
                    CmsObjectIdentifiers.SignedData,
                    signedData
                );

                // Encode to DER
                byte[] p7mBytes = pkcs7ContentInfo.GetDerEncoded();
                string p7mBase64 = Convert.ToBase64String(p7mBytes);

                // Calcola SHA-256 per diagnostica integrità trasmissione
                using (var sha256 = System.Security.Cryptography.SHA256.Create())
                {
                    byte[] hash = sha256.ComputeHash(p7mBytes);
                    string hashHex = BitConverter.ToString(hash).Replace("-", "").ToLower();
                    Log($"  ✓ CAdES-BES P7M created: {p7mBytes.Length} bytes");
                    Log($"  [INTEGRITY] P7M SHA-256: {hashHex}");
                    Log($"  [INTEGRITY] Base64 length: {p7mBase64.Length} chars");
                }
                Log($"  ContentType: signedData (1.2.840.113549.1.7.2)");
                Log($"  DigestAlgorithm: SHA-256 (2.16.840.1.101.3.4.2.1)");
                Log($"  SignatureAlgorithm: sha256WithRSAEncryption (1.2.840.113549.1.1.11)");

                return (true, p7mBase64, null, signedAt);
            }
            catch (Exception ex)
            {
                Log($"CreateCAdESSignatureBC error: {ex.GetType().Name}: {ex.Message}");
                Log($"  Stack trace: {ex.StackTrace}");
                return (false, null, $"Errore BouncyCastle: {ex.Message}", null);
            }
        }

        // ============================================================
        // CAdES-BES SIGNATURE LEGACY - Firma PKCS#7/P7M usando libSIAEp7.dll
        // Usa direttamente la smart card SIAE senza passare per Windows CSP
        // ATTENZIONE: Questa versione usa SHA-1 (deprecato)
        // ============================================================

        /// <summary>
        /// Crea firma PKCS#7/P7M usando libSIAEp7.dll direttamente dalla smart card SIAE
        /// LEGACY: Usa SHA-1 - preferire CreateCAdESSignatureBC per nuove implementazioni
        /// Ritorna il file P7M firmato in Base64
        /// </summary>
        static (bool success, string p7mBase64, string error, string signedAt) CreateCAdESSignatureLegacy(byte[] xmlBytes, string pin)
        {
            string inputFile = null;
            string outputFile = null;
            
            try
            {
                Log($"CreateCAdESSignature (libSIAEp7): xmlBytes.Length={xmlBytes.Length}, slot={_slot}");

                // Verifica che libSIAEp7.dll esista
                string p7DllPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "libSIAEp7.dll");
                if (!File.Exists(p7DllPath))
                {
                    Log($"  ERROR: libSIAEp7.dll not found at {p7DllPath}");
                    return (false, null, "libSIAEp7.dll non trovata - impossibile creare firma P7M", null);
                }
                Log($"  ✓ libSIAEp7.dll found: {new FileInfo(p7DllPath).Length} bytes");

                // Crea file temporanei per input/output
                string tempDir = Path.GetTempPath();
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                inputFile = Path.Combine(tempDir, $"siae_xml_{timestamp}.xml");
                outputFile = Path.Combine(tempDir, $"siae_xml_{timestamp}.xml.p7m");

                Log($"  Input file: {inputFile}");
                Log($"  Output file: {outputFile}");

                // Scrivi l'XML nel file temporaneo
                File.WriteAllBytes(inputFile, xmlBytes);
                Log($"  ✓ XML written to temp file ({xmlBytes.Length} bytes)");

                // Chiama PKCS7SignML per creare il P7M firmato
                // bInitialize = 1 perché libSIAEp7.dll ha una sessione separata da libSIAE.dll
                // La libreria p7 deve inizializzare la sua propria connessione alla smart card
                Log($"  Calling PKCS7SignML(pin=***, slot={_slot}, input={inputFile}, output={outputFile}, init=1)...");
                
                int result = PKCS7SignML(pin, (uint)_slot, inputFile, outputFile, 1);
                Log($"  PKCS7SignML returned: {result} (0x{result:X4})");

                if (result != 0)
                {
                    // Interpreta i codici di errore comuni
                    string errorMsg = result switch
                    {
                        0x6983 => "PIN bloccato - troppi tentativi errati",
                        0x6982 => "PIN errato - autenticazione fallita",
                        0x6A82 => "File non trovato sulla smart card",
                        0x6A80 => "Parametri errati",
                        _ when result >= 0x63C0 && result <= 0x63CF => $"PIN errato - tentativi rimasti: {result & 0x0F}",
                        _ => $"Errore firma PKCS7: 0x{result:X4}"
                    };
                    return (false, null, errorMsg, null);
                }

                // Verifica che il file P7M sia stato creato
                if (!File.Exists(outputFile))
                {
                    Log($"  ERROR: Output P7M file not created");
                    return (false, null, "File P7M non creato - errore durante la firma", null);
                }

                // Leggi il file P7M e converti in Base64
                byte[] p7mBytes = File.ReadAllBytes(outputFile);
                string p7mBase64 = Convert.ToBase64String(p7mBytes);
                string signedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz");

                // Calcola SHA-256 per diagnostica integrità trasmissione
                using (var sha256 = System.Security.Cryptography.SHA256.Create())
                {
                    byte[] hash = sha256.ComputeHash(p7mBytes);
                    string hashHex = BitConverter.ToString(hash).Replace("-", "").ToLower();
                    Log($"  ✓ P7M created successfully: {p7mBytes.Length} bytes");
                    Log($"  [INTEGRITY] P7M SHA-256: {hashHex}");
                    Log($"  [INTEGRITY] Base64 length: {p7mBase64.Length} chars");
                }

                return (true, p7mBase64, null, signedAt);
            }
            catch (DllNotFoundException dllEx)
            {
                Log($"CreateCAdESSignature DLL error: {dllEx.Message}");
                return (false, null, "libSIAEp7.dll non trovata o non caricabile", null);
            }
            catch (Exception ex)
            {
                Log($"CreateCAdESSignature error: {ex.GetType().Name}: {ex.Message}");
                return (false, null, ex.Message, null);
            }
            finally
            {
                // Pulisci i file temporanei
                try
                {
                    if (inputFile != null && File.Exists(inputFile))
                    {
                        File.Delete(inputFile);
                        Log($"  Cleaned up input file");
                    }
                    if (outputFile != null && File.Exists(outputFile))
                    {
                        File.Delete(outputFile);
                        Log($"  Cleaned up output file");
                    }
                }
                catch (Exception cleanupEx)
                {
                    Log($"  Cleanup error: {cleanupEx.Message}");
                }
            }
        }

        /// <summary>
        /// Cerca il certificato della Smart Card SIAE nello store Windows
        /// Il certificato deve essere emesso da una CA italiana riconosciuta (InfoCert, Aruba, etc.)
        /// e NON deve essere auto-firmato
        /// </summary>
        static X509Certificate2 GetSmartCardCertificateFromStore()
        {
            Log("  Searching for SIAE Smart Card certificate in Windows store...");

            // Cerca in entrambi gli store: CurrentUser e LocalMachine
            StoreLocation[] locations = { StoreLocation.CurrentUser, StoreLocation.LocalMachine };
            
            foreach (var location in locations)
            {
                try
                {
                    X509Store store = new X509Store(StoreName.My, location);
                    store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);

                    try
                    {
                        foreach (X509Certificate2 cert in store.Certificates)
                        {
                            // Deve avere una chiave privata (tipico delle Smart Card)
                            if (!cert.HasPrivateKey)
                                continue;

                            // Il certificato deve essere valido
                            if (DateTime.Now < cert.NotBefore || DateTime.Now > cert.NotAfter)
                                continue;

                            string issuer = cert.Issuer.ToUpperInvariant();
                            string subject = cert.Subject.ToUpperInvariant();

                            Log($"    [{location}] Checking cert: Subject={cert.Subject}, Issuer={cert.Issuer}");

                            // IMPORTANTE: Escludi certificati auto-firmati (Issuer == Subject)
                            // Questi sono tipicamente certificati di test/sviluppo, non SIAE
                            if (cert.Issuer == cert.Subject)
                            {
                                Log($"    -> Skipping self-signed certificate");
                                continue;
                            }

                            // Escludi certificati con GUID nel nome (tipicamente auto-generati)
                            if (System.Text.RegularExpressions.Regex.IsMatch(subject, @"[A-F0-9]{8}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{12}"))
                            {
                                Log($"    -> Skipping GUID-based certificate");
                                continue;
                            }

                            // Cerca certificati emessi da CA italiane riconosciute
                            // tipicamente usati per le carte SIAE
                            bool isSiaeCompatible = 
                                issuer.Contains("INFOCERT") ||
                                issuer.Contains("ARUBA") ||
                                issuer.Contains("ACTALIS") ||
                                issuer.Contains("POSTE") ||
                                issuer.Contains("NAMIRIAL") ||
                                issuer.Contains("INTESI") ||
                                issuer.Contains("TELECOM") ||
                                issuer.Contains("IN.TE.S.A") ||
                                subject.Contains("SIAE") ||
                                issuer.Contains("SIAE");

                            if (isSiaeCompatible)
                            {
                                Log($"    -> SIAE-compatible certificate found from {location}!");
                                store.Close();
                                return cert;
                            }
                        }
                    }
                    finally
                    {
                        store.Close();
                    }
                }
                catch (Exception ex)
                {
                    Log($"  Error accessing {location} store: {ex.Message}");
                }
            }

            Log($"  No SIAE-compatible certificate found in Windows store");
            Log($"  NOTE: The smart card certificate must be accessible via Windows CSP.");
            Log($"  Make sure the Bit4id minidriver is installed and the certificate is visible in certmgr.msc");
            return null;
        }

        // ============================================================
        // SIGN S/MIME - Firma S/MIME per email SIAE (Allegato C)
        // Per Provvedimento Agenzia Entrate 04/03/2008, sezione 1.6.1-1.6.2
        // L'email deve essere firmata S/MIME v2 con carta di attivazione
        // Usa libSIAEp7.dll (PKCS7SignML) per creare firma CMS valida
        // ============================================================
        static string SignSmime(string json)
        {
            if (_slot < 0) return ERR("Nessuna carta rilevata - prima fai CHECK_READER");

            string inputFile = null;
            string outputFile = null;

            try
            {
                dynamic req = JsonConvert.DeserializeObject(json);
                string mimeContent = req.mimeContent;
                string pin = req.pin;

                // NUOVO: Supporto formato SMIMESignML con parametri separati
                string smimeFrom = req.from;
                string smimeTo = req.to;
                string smimeSubject = req.subject;
                string smimeBody = req.body;
                string attachmentBase64 = req.attachmentBase64;
                string attachmentName = req.attachmentName;

                // Se abbiamo i nuovi parametri, costruisci il mimeContent
                // CRITICO: Per S/MIME multipart/signed, il contenuto da firmare NON deve includere
                // gli header esterni (From/To/Subject). Solo il body MIME viene firmato.
                // Gli header esterni verranno aggiunti DOPO la firma.
                string externalFrom = "";
                string externalTo = "";
                string externalSubject = "";
                
                if (!string.IsNullOrEmpty(smimeFrom) && !string.IsNullOrEmpty(smimeTo))
                {
                    Log($"SignSmime: Using SMIMESignML format - from={smimeFrom}, to={smimeTo}");
                    
                    // Salva gli header esterni per dopo (non firmati)
                    externalFrom = smimeFrom;
                    externalTo = smimeTo;
                    externalSubject = smimeSubject ?? "RCA Transmission";
                    
                    var mimeBuilder = new StringBuilder();
                    string boundary = $"----=_Part_{Guid.NewGuid():N}";
                    
                    // NON includere From/To/Subject qui - questi sono header esterni per il client email
                    // Il body MIME inizia da Content-Type e include tutto il contenuto firmato
                    
                    if (!string.IsNullOrEmpty(attachmentBase64) && !string.IsNullOrEmpty(attachmentName))
                    {
                        // Email con allegato - multipart/mixed (SENZA header From/To/Subject)
                        mimeBuilder.Append($"Content-Type: multipart/mixed; boundary=\"{boundary}\"\r\n");
                        mimeBuilder.Append("\r\n");
                        
                        // Parte body
                        mimeBuilder.Append($"--{boundary}\r\n");
                        mimeBuilder.Append("Content-Type: text/plain; charset=utf-8\r\n");
                        mimeBuilder.Append("Content-Transfer-Encoding: 8bit\r\n");
                        mimeBuilder.Append("\r\n");
                        mimeBuilder.Append(smimeBody ?? "SIAE RCA Transmission");
                        mimeBuilder.Append("\r\n\r\n");
                        
                        // Parte allegato P7M - usa application/octet-stream per file binari firmati
                        mimeBuilder.Append($"--{boundary}\r\n");
                        mimeBuilder.Append($"Content-Type: application/octet-stream; name=\"{attachmentName}\"\r\n");
                        mimeBuilder.Append("Content-Transfer-Encoding: base64\r\n");
                        mimeBuilder.Append($"Content-Disposition: attachment; filename=\"{attachmentName}\"\r\n");
                        mimeBuilder.Append("\r\n");
                        
                        // Formatta base64 in righe da 76 caratteri
                        for (int i = 0; i < attachmentBase64.Length; i += 76)
                        {
                            int len = Math.Min(76, attachmentBase64.Length - i);
                            mimeBuilder.Append(attachmentBase64.Substring(i, len));
                            mimeBuilder.Append("\r\n");
                        }
                        
                        mimeBuilder.Append($"--{boundary}--\r\n");
                    }
                    else
                    {
                        // Email senza allegato - text/plain (SENZA header From/To/Subject)
                        mimeBuilder.Append("Content-Type: text/plain; charset=utf-8\r\n");
                        mimeBuilder.Append("Content-Transfer-Encoding: 8bit\r\n");
                        mimeBuilder.Append("\r\n");
                        mimeBuilder.Append(smimeBody ?? "SIAE RCA Transmission");
                        mimeBuilder.Append("\r\n");
                    }
                    
                    mimeContent = mimeBuilder.ToString();
                    Log($"  Built MIME body (without external headers) for signing: {mimeContent.Length} bytes");
                }

                if (string.IsNullOrEmpty(mimeContent))
                {
                    return ERR("Contenuto MIME mancante - servono mimeContent oppure from/to/subject/body");
                }

                if (string.IsNullOrEmpty(pin))
                {
                    return ERR("PIN mancante - richiesto per firma S/MIME");
                }

                Log($"SignSmime (via libSIAEp7): slot={_slot}, mimeLength={mimeContent?.Length ?? 0}");

                int state = isCardIn(_slot);
                if (!IsCardPresent(state))
                {
                    _slot = -1;
                    return ERR("Carta rimossa");
                }

                // Usa libSIAEp7.dll (PKCS7SignML) per creare una firma CMS/PKCS#7 valida
                // Questa è la stessa libreria usata per CAdES-BES che funziona correttamente
                
                // Crea file temporanei per input/output
                string tempDir = Path.GetTempPath();
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
                inputFile = Path.Combine(tempDir, $"smime_input_{timestamp}.mime");
                outputFile = Path.Combine(tempDir, $"smime_output_{timestamp}.p7s");

                // Scrivi il contenuto MIME nel file input
                File.WriteAllText(inputFile, mimeContent, Encoding.UTF8);
                Log($"  Input file written: {inputFile} ({mimeContent.Length} bytes)");

                // Pulisci PIN
                pin = new string(pin.Where(char.IsDigit).ToArray());
                if (pin.Length < 4)
                {
                    return ERR("PIN non valido - deve contenere almeno 4 cifre");
                }

                // Chiama PKCS7SignML per creare la firma PKCS#7
                Log($"  Calling PKCS7SignML with PIN (length={pin.Length})...");
                int signResult = PKCS7SignML(pin, (uint)_slot, inputFile, outputFile, 1);
                Log($"  PKCS7SignML result: {signResult} (0x{signResult:X8})");

                if (signResult != 0)
                {
                    // Interpreta codici errore smart card
                    if (signResult == 0x6983 || signResult == unchecked((int)0x80100068))
                        return ERR("PIN bloccato - troppi tentativi errati. Usa PUK per sbloccare.");
                    else if (signResult == 0x6982)
                        return ERR("PIN errato - autenticazione fallita");
                    else if (signResult >= 0x63C0 && signResult <= 0x63CF)
                        return ERR($"PIN errato - tentativi rimasti: {signResult & 0x0F}");
                    else
                        return ERR($"Firma S/MIME fallita: errore 0x{signResult:X8}");
                }

                // Verifica che il file output esista
                if (!File.Exists(outputFile))
                {
                    return ERR("File firma P7S non creato da PKCS7SignML");
                }

                // Leggi la firma PKCS#7 dal file output
                byte[] p7sBytes = File.ReadAllBytes(outputFile);
                Log($"  P7S signature file read: {p7sBytes.Length} bytes");

                if (p7sBytes.Length < 100)
                {
                    return ERR("Firma P7S troppo corta - probabilmente non valida");
                }

                // Leggi il certificato per estrarre email e nome
                string signerEmail = "";
                string signerName = "";
                
                int finRes = FinalizeML(_slot);
                int init = Initialize(_slot);
                int txResult = BeginTransactionML(_slot);
                bool tx = (txResult == 0);
                
                try
                {
                    LibSiae.SelectML(0x0000, _slot);
                    LibSiae.SelectML(0x1111, _slot);
                    
                    byte[] cert = new byte[2048];
                    int certLen = cert.Length;
                    int certResult = LibSiae.GetCertificateML(cert, ref certLen, _slot);
                    
                    if (certResult == 0 && certLen > 0)
                    {
                        byte[] actualCert = new byte[certLen];
                        Array.Copy(cert, actualCert, certLen);
                        
                        var x509 = new System.Security.Cryptography.X509Certificates.X509Certificate2(actualCert);
                        signerName = x509.GetNameInfo(System.Security.Cryptography.X509Certificates.X509NameType.SimpleName, false) ?? "";
                        
                        // Cerca email nel SAN (Subject Alternative Name)
                        foreach (var ext in x509.Extensions)
                        {
                            if (ext.Oid?.Value == "2.5.29.17")
                            {
                                var sanString = ext.Format(false);
                                Log($"  SAN extension: {sanString}");
                                
                                // Pattern multipli per trovare email
                                var patterns = new[] {
                                    @"RFC822[^=]*=([^\s,]+)",
                                    @"email:([^\s,]+)",
                                    @"rfc822Name=([^\s,]+)"
                                };
                                
                                foreach (var pattern in patterns)
                                {
                                    var match = System.Text.RegularExpressions.Regex.Match(sanString, pattern, System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                                    if (match.Success)
                                    {
                                        signerEmail = match.Groups[1].Value;
                                        Log($"  Found email in SAN: {signerEmail}");
                                        break;
                                    }
                                }
                                if (!string.IsNullOrEmpty(signerEmail)) break;
                            }
                        }
                        
                        // Fallback: cerca nel Subject
                        if (string.IsNullOrEmpty(signerEmail))
                        {
                            var subject = x509.Subject;
                            Log($"  Subject: {subject}");
                            
                            var emailPatterns = new[] {
                                @"E=([^\s,]+)",
                                @"EMAIL=([^\s,]+)",
                                @"EMAILADDRESS=([^\s,]+)"
                            };
                            
                            foreach (var pattern in emailPatterns)
                            {
                                var match = System.Text.RegularExpressions.Regex.Match(subject, pattern, System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                                if (match.Success)
                                {
                                    signerEmail = match.Groups[1].Value.Trim();
                                    Log($"  Found email in Subject: {signerEmail}");
                                    break;
                                }
                            }
                        }
                        
                        Log($"  Certificate: Name={signerName}, Email={signerEmail}");
                    }
                }
                catch (Exception certEx)
                {
                    Log($"  Certificate parsing error: {certEx.Message}");
                }
                finally
                {
                    if (tx) try { EndTransactionML(_slot); } catch { }
                }

                // Costruisci il messaggio S/MIME multipart/signed
                // CRITICO RFC 5751: Gli header From/To/Subject devono essere ESTERNI alla struttura multipart/signed
                // Questi header sono visibili al client email e NON fanno parte del contenuto firmato
                string signedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz");
                string smimeBoundary = $"----=_smime_{Guid.NewGuid():N}";
                string p7sBase64 = Convert.ToBase64String(p7sBytes);

                // Il mimeContent costruito sopra NON contiene header From/To/Subject
                // È già il body MIME puro che è stato firmato da PKCS7SignML
                // Lo normalizziamo solo per garantire line endings corretti
                string bodyMime = mimeContent.Replace("\r\n", "\n").Replace("\n", "\r\n");
                
                Log($"  Building S/MIME message: From={!string.IsNullOrEmpty(externalFrom)}, To={!string.IsNullOrEmpty(externalTo)}, Subject={!string.IsNullOrEmpty(externalSubject)}");
                Log($"  Body MIME size: {bodyMime.Length} bytes (this is what was signed)");

                var smimeBuilder = new StringBuilder();
                
                // PRIMA: Header esterni (visibili al client email, NON firmati)
                // Questi provengono dalle variabili salvate quando abbiamo costruito mimeContent
                if (!string.IsNullOrEmpty(externalFrom))
                    smimeBuilder.Append($"From: {externalFrom}\r\n");
                if (!string.IsNullOrEmpty(externalTo))
                    smimeBuilder.Append($"To: {externalTo}\r\n");
                if (!string.IsNullOrEmpty(externalSubject))
                    smimeBuilder.Append($"Subject: {externalSubject}\r\n");
                
                // DOPO: Header MIME per multipart/signed
                smimeBuilder.Append("MIME-Version: 1.0\r\n");
                smimeBuilder.Append($"Content-Type: multipart/signed; protocol=\"application/pkcs7-signature\"; micalg=sha-256; boundary=\"{smimeBoundary}\"\r\n");
                smimeBuilder.Append("\r\n");
                smimeBuilder.Append($"--{smimeBoundary}\r\n");
                
                // Aggiungi il body MIME - questo è ESATTAMENTE il contenuto che è stato firmato
                // CRITICO: bodyMime deve essere identico a ciò che è stato scritto in inputFile per PKCS7SignML
                smimeBuilder.Append(bodyMime);
                if (!bodyMime.EndsWith("\r\n"))
                    smimeBuilder.Append("\r\n");
                
                smimeBuilder.Append("\r\n");
                smimeBuilder.Append($"--{smimeBoundary}\r\n");
                smimeBuilder.Append("Content-Type: application/pkcs7-signature; name=\"smime.p7s\"\r\n");
                smimeBuilder.Append("Content-Transfer-Encoding: base64\r\n");
                smimeBuilder.Append("Content-Disposition: attachment; filename=\"smime.p7s\"\r\n");
                smimeBuilder.Append("\r\n");
                
                // Dividi base64 in righe da 76 caratteri
                for (int i = 0; i < p7sBase64.Length; i += 76)
                {
                    int len = Math.Min(76, p7sBase64.Length - i);
                    smimeBuilder.Append(p7sBase64.Substring(i, len));
                    smimeBuilder.Append("\r\n");
                }
                
                smimeBuilder.Append($"--{smimeBoundary}--\r\n");

                string signedMime = smimeBuilder.ToString();
                Log($"  S/MIME message built: {signedMime.Length} bytes");

                return JsonConvert.SerializeObject(new
                {
                    success = true,
                    signature = new
                    {
                        signedMime = signedMime,
                        signerEmail = signerEmail,
                        signerName = signerName,
                        signedAt = signedAt,
                        format = "S/MIME",
                        algorithm = "SHA-256"
                    }
                });
            }
            catch (Exception ex)
            {
                Log($"SignSmime error: {ex.Message}\n{ex.StackTrace}");
                return ERR(ex.Message);
            }
            finally
            {
                // Pulisci file temporanei
                try
                {
                    if (inputFile != null && File.Exists(inputFile))
                        File.Delete(inputFile);
                    if (outputFile != null && File.Exists(outputFile))
                        File.Delete(outputFile);
                }
                catch { }
            }
        }
    }
}
