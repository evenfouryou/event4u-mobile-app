# Event Four You SIAE Lettore

App desktop per la lettura di smart card SIAE per il sistema Event4U.

## Installazione

1. Scarica l'installer dalla sezione **Releases**
2. Esegui `Event Four You SIAE Lettore Setup.exe`
3. L'app si connetterà automaticamente al server

## Requisiti

- Windows 10/11
- Lettore smart card PC/SC compatibile

## Funzionalità

- Lettura smart card SIAE
- Connessione automatica al server relay
- Riconnessione automatica in caso di disconnessione
